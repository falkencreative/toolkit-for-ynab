'use strict';

(function poll() {
  if (typeof ynabToolKit !== 'undefined' && ynabToolKit.pageReady === true) {
    ynabToolKit.compactIncomeExpense = function () {
      return {
        invoke: function invoke() {
          var viewWidth = $('.reports-content').width();
          var columnCount = $('.income-expense-column.income-expense-column-header').length;
          var tableWidth = columnCount * 115 + 200 + 32;
          var percentage = Math.ceil(tableWidth / viewWidth * 100);
          $('.income-expense-table').css({
            width: percentage + '%'
          });
        },
        observe: function observe(changedNodes) {
          var currentRoute = ynabToolKit.shared.getCurrentRoute();
          if (changedNodes.has('income-expense-column') && currentRoute === 'reports.income-expense') {
            ynabToolKit.compactIncomeExpense.invoke();
          }
        }
      };
    }();

    var currentRoute = ynabToolKit.shared.getCurrentRoute();
    if (currentRoute === 'reports.income-expense') {
      ynabToolKit.compactIncomeExpense.invoke();
    }
  } else {
    setTimeout(poll, 250);
  }
})();