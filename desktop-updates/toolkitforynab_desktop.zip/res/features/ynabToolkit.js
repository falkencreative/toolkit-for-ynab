'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/******/(function (modules) {
  // webpackBootstrap
  /******/ // The module cache
  /******/var installedModules = {};
  /******/
  /******/ // The require function
  /******/function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId]) {
      /******/return installedModules[moduleId].exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/i: moduleId,
      /******/l: false,
      /******/exports: {}
      /******/ };
    /******/
    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/
    /******/ // Flag the module as loaded
    /******/module.l = true;
    /******/
    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/
  }
  /******/
  /******/
  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;
  /******/
  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;
  /******/
  /******/ // define getter function for harmony exports
  /******/__webpack_require__.d = function (exports, name, getter) {
    /******/if (!__webpack_require__.o(exports, name)) {
      /******/Object.defineProperty(exports, name, {
        /******/configurable: false,
        /******/enumerable: true,
        /******/get: getter
        /******/ });
      /******/
    }
    /******/
  };
  /******/
  /******/ // getDefaultExport function for compatibility with non-harmony modules
  /******/__webpack_require__.n = function (module) {
    /******/var getter = module && module.__esModule ?
    /******/function getDefault() {
      return module['default'];
    } :
    /******/function getModuleExports() {
      return module;
    };
    /******/__webpack_require__.d(getter, 'a', getter);
    /******/return getter;
    /******/
  };
  /******/
  /******/ // Object.prototype.hasOwnProperty.call
  /******/__webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/
  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "";
  /******/
  /******/ // Load entry module and return exports
  /******/return __webpack_require__(__webpack_require__.s = 6);
  /******/
})(
/************************************************************************/
/******/[
/* 0 */
/***/function (module, exports) {

  /*
  	MIT License http://www.opensource.org/licenses/mit-license.php
  	Author Tobias Koppers @sokra
  */
  // css base code, injected by the css-loader
  module.exports = function (useSourceMap) {
    var list = [];

    // return the list of modules as css string
    list.toString = function toString() {
      return this.map(function (item) {
        var content = cssWithMappingToString(item, useSourceMap);
        if (item[2]) {
          return "@media " + item[2] + "{" + content + "}";
        } else {
          return content;
        }
      }).join("");
    };

    // import a list of modules into the list
    list.i = function (modules, mediaQuery) {
      if (typeof modules === "string") modules = [[null, modules, ""]];
      var alreadyImportedModules = {};
      for (var i = 0; i < this.length; i++) {
        var id = this[i][0];
        if (typeof id === "number") alreadyImportedModules[id] = true;
      }
      for (i = 0; i < modules.length; i++) {
        var item = modules[i];
        // skip already imported module
        // this implementation is not 100% perfect for weird media query combinations
        //  when a module is imported multiple times with different media queries.
        //  I hope this will never occur (Hey this way we have smaller bundles)
        if (typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
          if (mediaQuery && !item[2]) {
            item[2] = mediaQuery;
          } else if (mediaQuery) {
            item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
          }
          list.push(item);
        }
      }
    };
    return list;
  };

  function cssWithMappingToString(item, useSourceMap) {
    var content = item[1] || '';
    var cssMapping = item[3];
    if (!cssMapping) {
      return content;
    }

    if (useSourceMap && typeof btoa === 'function') {
      var sourceMapping = toComment(cssMapping);
      var sourceURLs = cssMapping.sources.map(function (source) {
        return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */';
      });

      return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
    }

    return [content].join('\n');
  }

  // Adapted from convert-source-map (MIT)
  function toComment(sourceMap) {
    // eslint-disable-next-line no-undef
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
    var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;

    return '/*# ' + data + ' */';
  }

  /***/
},
/* 1 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Feature = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _listeners = __webpack_require__(9);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var Feature = exports.Feature = function () {
    function Feature() {
      _classCallCheck(this, Feature);

      this.settings = {
        enabled: ynabToolKit.options[this.constructor.name]
      };
    }

    _createClass(Feature, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        // Default to no action. Unless you're implementing a CSS only feature,
        // you MUST override this to specify when your invoke() function should run!
        return false;
      }
    }, {
      key: 'willInvoke',
      value: function willInvoke() {
        /* stubbed optional hook for logic that must happen for a feature
        to work but doesn't need to happen on every invoke */
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        throw Error('Feature: ' + this.constructor.name + ' does not implement required invoke() method.');
      }
    }, {
      key: 'injectCSS',
      value: function injectCSS() {/* stubbed, default to no injected CSS */}
    }, {
      key: 'observe',
      value: function observe() {/* stubbed listener function */}
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {/* stubbed listener function */}
    }, {
      key: 'onBudgetChanged',
      value: function onBudgetChanged() {/* stubbed listener function */}
    }, {
      key: 'applyListeners',
      value: function applyListeners() {
        var observeListener = new _listeners.ObserveListener();
        observeListener.addFeature(this);

        var routeChangeListener = new _listeners.RouteChangeListener();
        routeChangeListener.addFeature(this);
      }
    }]);

    return Feature;
  }();

  /***/
},
/* 2 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.controllerLookup = controllerLookup;
  exports.componentLookup = componentLookup;
  exports.getEmberView = getEmberView;
  exports.getCurrentRouteName = getCurrentRouteName;
  exports.getCategoriesViewModel = getCategoriesViewModel;
  exports.getAllBudgetMonthsViewModel = getAllBudgetMonthsViewModel;
  exports.getCurrentDate = getCurrentDate;
  exports.getRouter = getRouter;
  exports.formatCurrency = formatCurrency;
  exports.getEntityManager = getEntityManager;
  exports.getToolkitStorageKey = getToolkitStorageKey;
  exports.setToolkitStorageKey = setToolkitStorageKey;
  exports.removeToolkitStorageKey = removeToolkitStorageKey;
  exports.transitionTo = transitionTo;
  exports.i10n = i10n;
  var STORAGE_KEY_PREFIX = 'ynab-toolkit-';

  function controllerLookup(controllerName) {
    return containerLookup('controller:' + controllerName);
  }

  function componentLookup(componentName) {
    return containerLookup('component:' + componentName);
  }

  function getEmberView(viewId) {
    return getViewRegistry()[viewId];
  }

  function getCurrentRouteName() {
    var applicationController = controllerLookup('application');
    return applicationController.get('currentRouteName');
  }

  function getCategoriesViewModel() {
    return ynab.YNABSharedLib.getBudgetViewModel_CategoriesViewModel();
  }

  function getAllBudgetMonthsViewModel() {
    return ynab.YNABSharedLib.getBudgetViewModel_AllBudgetMonthsViewModel();
  }

  function getCurrentDate(format) {
    return ynabDate(format, false);
  }

  function getRouter() {
    return containerLookup('router:main');
  }

  function formatCurrency(value) {
    var currencyFormatter = ynab.YNABSharedLibWebInstance.firstInstanceCreated.formattingManager.currencyFormatter;

    var userCurrency = currencyFormatter.getCurrency();

    var formattedCurrency = currencyFormatter.format(value).toString();
    if (userCurrency.symbol_first) {
      if (formattedCurrency.charAt(0) === '-') {
        formattedCurrency = '-' + userCurrency.currency_symbol + formattedCurrency.slice(1);
      } else {
        formattedCurrency = '' + userCurrency.currency_symbol + formattedCurrency;
      }
    } else {
      formattedCurrency = '' + formattedCurrency + userCurrency.currency_symbol;
    }

    return formattedCurrency;
  }

  function getEntityManager() {
    return ynab.YNABSharedLib.defaultInstance.entityManager;
  }

  function getToolkitStorageKey(key, type) {
    var value = localStorage.getItem(STORAGE_KEY_PREFIX + key);

    switch (type) {
      case 'boolean':
        return value === 'true';
      case 'number':
        return Number(value);
      default:
        return value;
    }
  }

  function setToolkitStorageKey(key, value) {
    return localStorage.setItem(STORAGE_KEY_PREFIX + key, value);
  }

  function removeToolkitStorageKey(key) {
    return localStorage.removeItem(STORAGE_KEY_PREFIX + key);
  }

  function transitionTo() {
    var router = containerLookup('router:main');
    router.transitionTo.apply(router, arguments);
  }

  function i10n(key, defaultValue) {
    return ynabToolKit.l10nData && ynabToolKit.l10nData[key] || defaultValue;
  }

  /* Private Functions */
  function getViewRegistry() {
    return Ember.Component.create().get('_viewRegistry');
  }

  function containerLookup(containerName) {
    var viewRegistry = getViewRegistry();
    var viewId = Ember.keys(viewRegistry)[0];
    var view = viewRegistry[viewId];

    var container = void 0;
    try {
      container = view.container.lookup(containerName);
    } catch (e) {
      container = view.container.factoryCache[containerName];
    }

    return container;
  }

  function ynabDate(format) {
    if (typeof format !== 'string') {
      return ynab.YNABSharedLib.dateFormatter.formatDate();
    }

    return ynab.YNABSharedLib.dateFormatter.formatDate(moment(), format);
  }

  /***/
},
/* 3 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-table-row.is-sub-category > .budget-table-cell-available .positive,\n.budget-table-row.is-sub-category > .budget-table-cell-available .negative,\n.budget-table-row.is-sub-category > .budget-table-cell-available .cautious,\n.budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n    font-size: .9285em;\n}\n\n.budget-table-header .budget-table-cell-button, .budget-table-row .budget-table-cell-button {\n    font-size: .9285em;\n}\n", ""]);

  // exports


  /***/
},
/* 4 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(135);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 5 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(136);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 6 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var _features = __webpack_require__(7);

  var _features2 = _interopRequireDefault(_features);

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
  }

  var featureInstances = _features2.default.map(function (Feature) {
    return new Feature();
  });

  function isYNABReady() {
    return typeof Em !== 'undefined' && typeof Ember !== 'undefined' && typeof $ !== 'undefined' && $('.ember-view.layout').length && typeof ynabToolKit !== 'undefined';
  }

  // Check if the passed feature is enabled.
  function isFeatureEnabled(feature) {
    return typeof feature.settings.enabled === 'boolean' && feature.settings.enabled || typeof feature.settings.enabled === 'string' && feature.settings.enabled !== '0' // assumes '0' means disabled
    ;
  }

  // This poll() function will only need to run until we find that the DOM is ready
  (function poll() {
    if (isYNABReady()) {
      // Gather any desired global CSS from features
      var globalCSS = '';

      featureInstances.forEach(function (feature) {
        if (isFeatureEnabled(feature) && feature.injectCSS()) {
          globalCSS += '/* == Injected CSS from feature: ' + feature.constructor.name + ' == */\n\n' + feature.injectCSS() + '\n';
        }
      });

      ynabToolKit.invokeFeature = function (featureName) {
        var feature = featureInstances.find(function (f) {
          return f.constructor.name === featureName;
        });
        if (isFeatureEnabled(feature) && feature.shouldInvoke()) {
          feature.invoke();
        }
      };

      // Inject it into the head so it's left alone
      $('head').append($('<style>', { id: 'toolkit-injected-styles', type: 'text/css' }).text(globalCSS));

      // Hook up listeners and then invoke any features that are ready to go.
      featureInstances.forEach(function (feature) {
        if (isFeatureEnabled(feature)) {
          feature.applyListeners();

          var willInvokeRetValue = feature.willInvoke();

          if (willInvokeRetValue && typeof willInvokeRetValue.then === 'function') {
            willInvokeRetValue.then(function () {
              if (feature.shouldInvoke()) {
                feature.invoke();
              }
            });
          } else {
            if (feature.shouldInvoke()) {
              feature.invoke();
            }
          }
        }
      });
    } else {
      setTimeout(poll, 250);
    }
  })();

  /***/
},
/* 7 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });

  var _additionalColumns = __webpack_require__(8);

  var _adjustableColumnWidths = __webpack_require__(19);

  var _calendarFirstDay = __webpack_require__(22);

  var _changeEnterBehavior = __webpack_require__(23);

  var _clearSelection = __webpack_require__(24);

  var _customFlagNames = __webpack_require__(25);

  var _emphasizedOutflows = __webpack_require__(26);

  var _largerClearedIcons = __webpack_require__(29);

  var _rowHeight = __webpack_require__(32);

  var _showCategoryBalance = __webpack_require__(39);

  var _splitKeyboardShortcut = __webpack_require__(40);

  var _stripedRows = __webpack_require__(41);

  var _activityTransactionLink = __webpack_require__(44);

  var _budgetBalanceToZero = __webpack_require__(47);

  var _categoryActivityCopy = __webpack_require__(48);

  var _categoryActivityPopupWidth = __webpack_require__(49);

  var _daysOfBuffering = __webpack_require__(54);

  var _displayGoalAmount = __webpack_require__(61);

  var _enableRetroCalculator = __webpack_require__(62);

  var _goalWarningColor = __webpack_require__(63);

  var _highlightCurrentMonth = __webpack_require__(66);

  var _monthlyNotesPopupWidth = __webpack_require__(69);

  var _quickBudgetWarning = __webpack_require__(74);

  var _removePositiveHighlight = __webpack_require__(75);

  var _resizeInspector = __webpack_require__(78);

  var _rowsHeight = __webpack_require__(81);

  var _seamlessBudgetHeader = __webpack_require__(88);

  var _stealingFromFuture = __webpack_require__(91);

  var _targetBalanceWarning = __webpack_require__(94);

  var _toBeBudgetedWarning = __webpack_require__(95);

  var _toggleMasterCategories = __webpack_require__(98);

  var _accountsDisplayDensity = __webpack_require__(101);

  var _betterScrollbars = __webpack_require__(106);

  var _budgetQuickSwitch = __webpack_require__(113);

  var _collapseSideMenu = __webpack_require__(114);

  var _colourBlindMode = __webpack_require__(117);

  var _editAccountButton = __webpack_require__(120);

  var _googleFontsSelector = __webpack_require__(125);

  var _hideAccountBalances = __webpack_require__(134);

  var _hideAgeOfMoney = __webpack_require__(137);

  var _hideHelp = __webpack_require__(140);

  var _hideReferralBanner = __webpack_require__(143);

  var _importNotification = __webpack_require__(146);

  var _navDisplayDensity = __webpack_require__(149);

  var _printingImprovements = __webpack_require__(154);

  var _privacyMode = __webpack_require__(157);

  var _showIntercom = __webpack_require__(162);

  var _squareNegativeMode = __webpack_require__(163);

  /*
   ***********************************************************
   * Warning: This is a file generated by the build process. *
   *                                                         *
   * Any changes you make manually will be overwritten       *
   * the next time you run webpack!                          *
   ***********************************************************
  */
  if (!_additionalColumns.AdditionalColumns) {
    throw new Error('AdditionalColumns feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_adjustableColumnWidths.AdjustableColumnWidths) {
    throw new Error('AdjustableColumnWidths feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_calendarFirstDay.CalendarFirstDay) {
    throw new Error('CalendarFirstDay feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_changeEnterBehavior.ChangeEnterBehavior) {
    throw new Error('ChangeEnterBehavior feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_clearSelection.ClearSelection) {
    throw new Error('ClearSelection feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_customFlagNames.CustomFlagNames) {
    throw new Error('CustomFlagNames feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_emphasizedOutflows.AccountsEmphasizedOutflows) {
    throw new Error('AccountsEmphasizedOutflows feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_largerClearedIcons.LargerClickableIcons) {
    throw new Error('LargerClickableIcons feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_rowHeight.RowHeight) {
    throw new Error('RowHeight feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_showCategoryBalance.ShowCategoryBalance) {
    throw new Error('ShowCategoryBalance feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_splitKeyboardShortcut.SplitKeyboardShortcut) {
    throw new Error('SplitKeyboardShortcut feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_stripedRows.AccountsStripedRows) {
    throw new Error('AccountsStripedRows feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_activityTransactionLink.ActivityTransactionLink) {
    throw new Error('ActivityTransactionLink feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_budgetBalanceToZero.BudgetBalanceToZero) {
    throw new Error('BudgetBalanceToZero feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_categoryActivityCopy.CategoryActivityCopy) {
    throw new Error('CategoryActivityCopy feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_categoryActivityPopupWidth.CategoryActivityPopupWidth) {
    throw new Error('CategoryActivityPopupWidth feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_daysOfBuffering.DaysOfBuffering) {
    throw new Error('DaysOfBuffering feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_displayGoalAmount.DisplayTargetGoalAmount) {
    throw new Error('DisplayTargetGoalAmount feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_enableRetroCalculator.EnableRetroCalculator) {
    throw new Error('EnableRetroCalculator feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_goalWarningColor.GoalWarningColor) {
    throw new Error('GoalWarningColor feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_highlightCurrentMonth.CurrentMonthIndicator) {
    throw new Error('CurrentMonthIndicator feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_monthlyNotesPopupWidth.MonthlyNotesPopupWidth) {
    throw new Error('MonthlyNotesPopupWidth feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_quickBudgetWarning.QuickBudgetWarning) {
    throw new Error('QuickBudgetWarning feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_removePositiveHighlight.RemovePositiveHighlight) {
    throw new Error('RemovePositiveHighlight feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_resizeInspector.ResizeInspector) {
    throw new Error('ResizeInspector feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_rowsHeight.RowsHeight) {
    throw new Error('RowsHeight feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_seamlessBudgetHeader.SeamlessBudgetHeader) {
    throw new Error('SeamlessBudgetHeader feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_stealingFromFuture.StealingFromFuture) {
    throw new Error('StealingFromFuture feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_targetBalanceWarning.TargetBalanceWarning) {
    throw new Error('TargetBalanceWarning feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_toBeBudgetedWarning.ToBeBudgetedWarning) {
    throw new Error('ToBeBudgetedWarning feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_toggleMasterCategories.ToggleMasterCategories) {
    throw new Error('ToggleMasterCategories feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_accountsDisplayDensity.AccountsDisplayDensity) {
    throw new Error('AccountsDisplayDensity feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_betterScrollbars.BetterScrollbars) {
    throw new Error('BetterScrollbars feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_budgetQuickSwitch.BudgetQuickSwitch) {
    throw new Error('BudgetQuickSwitch feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_collapseSideMenu.CollapseSideMenu) {
    throw new Error('CollapseSideMenu feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_colourBlindMode.ColourBlindMode) {
    throw new Error('ColourBlindMode feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_editAccountButton.EditAccountButton) {
    throw new Error('EditAccountButton feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_googleFontsSelector.GoogleFontsSelector) {
    throw new Error('GoogleFontsSelector feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_hideAccountBalances.HideAccountBalancesType) {
    throw new Error('HideAccountBalancesType feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_hideAgeOfMoney.HideAgeOfMoney) {
    throw new Error('HideAgeOfMoney feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_hideHelp.HideHelp) {
    throw new Error('HideHelp feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_hideReferralBanner.HideReferralBanner) {
    throw new Error('HideReferralBanner feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_importNotification.ImportNotification) {
    throw new Error('ImportNotification feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_navDisplayDensity.NavDisplayDensity) {
    throw new Error('NavDisplayDensity feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_printingImprovements.PrintingImprovements) {
    throw new Error('PrintingImprovements feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_privacyMode.PrivacyMode) {
    throw new Error('PrivacyMode feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_showIntercom.ShowIntercom) {
    throw new Error('ShowIntercom feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }
  if (!_squareNegativeMode.SquareNegativeMode) {
    throw new Error('SquareNegativeMode feature failed to import. Have you set the name in the settings.js file to match the class name?');
  }

  var features = [_additionalColumns.AdditionalColumns, _adjustableColumnWidths.AdjustableColumnWidths, _calendarFirstDay.CalendarFirstDay, _changeEnterBehavior.ChangeEnterBehavior, _clearSelection.ClearSelection, _customFlagNames.CustomFlagNames, _emphasizedOutflows.AccountsEmphasizedOutflows, _largerClearedIcons.LargerClickableIcons, _rowHeight.RowHeight, _showCategoryBalance.ShowCategoryBalance, _splitKeyboardShortcut.SplitKeyboardShortcut, _stripedRows.AccountsStripedRows, _activityTransactionLink.ActivityTransactionLink, _budgetBalanceToZero.BudgetBalanceToZero, _categoryActivityCopy.CategoryActivityCopy, _categoryActivityPopupWidth.CategoryActivityPopupWidth, _daysOfBuffering.DaysOfBuffering, _displayGoalAmount.DisplayTargetGoalAmount, _enableRetroCalculator.EnableRetroCalculator, _goalWarningColor.GoalWarningColor, _highlightCurrentMonth.CurrentMonthIndicator, _monthlyNotesPopupWidth.MonthlyNotesPopupWidth, _quickBudgetWarning.QuickBudgetWarning, _removePositiveHighlight.RemovePositiveHighlight, _resizeInspector.ResizeInspector, _rowsHeight.RowsHeight, _seamlessBudgetHeader.SeamlessBudgetHeader, _stealingFromFuture.StealingFromFuture, _targetBalanceWarning.TargetBalanceWarning, _toBeBudgetedWarning.ToBeBudgetedWarning, _toggleMasterCategories.ToggleMasterCategories, _accountsDisplayDensity.AccountsDisplayDensity, _betterScrollbars.BetterScrollbars, _budgetQuickSwitch.BudgetQuickSwitch, _collapseSideMenu.CollapseSideMenu, _colourBlindMode.ColourBlindMode, _editAccountButton.EditAccountButton, _googleFontsSelector.GoogleFontsSelector, _hideAccountBalances.HideAccountBalancesType, _hideAgeOfMoney.HideAgeOfMoney, _hideHelp.HideHelp, _hideReferralBanner.HideReferralBanner, _importNotification.ImportNotification, _navDisplayDensity.NavDisplayDensity, _printingImprovements.PrintingImprovements, _privacyMode.PrivacyMode, _showIntercom.ShowIntercom, _squareNegativeMode.SquareNegativeMode];

  exports.default = features;

  /***/
},
/* 8 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.AdditionalColumns = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _additionalColumnStub = __webpack_require__(12);

  var _runningBalance = __webpack_require__(13);

  var _checkNumbers = __webpack_require__(14);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var AdditionalColumns = exports.AdditionalColumns = function (_Feature) {
    _inherits(AdditionalColumns, _Feature);

    function AdditionalColumns() {
      _classCallCheck(this, AdditionalColumns);

      var _this2 = _possibleConstructorReturn(this, (AdditionalColumns.__proto__ || Object.getPrototypeOf(AdditionalColumns)).call(this));

      _this2.checkNumbers = ynabToolKit.options.CheckNumbers ? new _checkNumbers.CheckNumbers() : new _additionalColumnStub.AdditionalColumnStub();
      _this2.runningBalance = ynabToolKit.options.RunningBalance !== '0' ? new _runningBalance.RunningBalance() : new _additionalColumnStub.AdditionalColumnStub();
      return _this2;
    }

    _createClass(AdditionalColumns, [{
      key: 'injectCSS',
      value: function injectCSS() {
        var css = __webpack_require__(15);

        if (ynabToolKit.options.RunningBalance === '1') {
          css += __webpack_require__(17);
        }

        return css;
      }
    }, {
      key: 'willInvoke',
      value: function willInvoke() {
        // any of the components added here must be loaded when YNAB loads. if they
        // are not available in the cache, this feature will crash. move them to
        // invoke function if that is the case.
        this.attachWillInsertHandler('register/grid-sub');
        this.attachWillInsertHandler('register/grid-row');
        this.attachWillInsertHandler('register/grid-scheduled');
        this.attachWillInsertHandler('register/grid-scheduled-sub');
        this.attachWillInsertHandler('register/grid-actions');
        this.attachWillInsertHandler('register/grid-split');

        return Promise.all([this.checkNumbers.willInvoke(), this.runningBalance.willInvoke()]);
      }

      // we always want to invoke this feature if it's enabled because we want
      // to at least initialize running balance on all of the accounts

    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return this.runningBalance.shouldInvoke() || this.checkNumbers.shouldInvoke();
      }
    }, {
      key: 'attachWillInsertHandler',
      value: function attachWillInsertHandler(componentName) {
        var _this = this;
        var GridComponent = toolkitHelper.componentLookup(componentName);

        if (GridComponent.__toolkitInitialized) {
          return;
        }

        try {
          GridComponent.constructor.reopen({
            willInsertElement: function willInsertElement() {
              if (_this.checkNumbers.shouldInvoke()) {
                _this.checkNumbers.willInsertColumn.call(this);
              }

              if (_this.runningBalance.shouldInvoke()) {
                _this.runningBalance.willInsertColumn.call(this);
              }
            }
          });
        } catch (e) {
          GridComponent.reopen({
            willInsertElement: function willInsertElement() {
              if (_this.checkNumbers.shouldInvoke()) {
                _this.checkNumbers.willInsertColumn.call(this);
              }

              if (_this.runningBalance.shouldInvoke()) {
                _this.runningBalance.willInsertColumn.call(this);
              }
            }
          });
        }

        // this is really hacky but I'm not sure what else to do, most of these components
        // double render so the `willInsertElement` works for those but the add rows
        // and footer are weird. add-rows doesn't double render and will work every time
        // after the component has been cached but footer is _always_ a new component WutFace
        var $appendToRows = void 0;
        switch (componentName) {
          case 'register/grid-add':
            $appendToRows = $('.ynab-grid-add-rows .ynab-grid-body-row.is-editing');
            break;
          case 'register/grid-sub-edit':
            $appendToRows = $('.ynab-grid-body-sub.is-editing');
            break;
          case 'register/grid-footer':
            $appendToRows = $('.ynab-grid-body-row.ynab-grid-footer');
            break;
        }

        if ($appendToRows) {
          this.checkNumbers.handleSingleRenderColumn($appendToRows, componentName);
          this.runningBalance.handleSingleRenderColumn($appendToRows, componentName);
        }

        GridComponent.__toolkitInitialized = true;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        if (this.checkNumbers.shouldInvoke()) {
          this.checkNumbers.insertHeader();
        }

        if (this.runningBalance.shouldInvoke()) {
          this.runningBalance.insertHeader();
        }

        if ($('.ynab-grid-body-row.is-editing', '.ynab-grid-body').length) {
          this.attachWillInsertHandler('register/grid-edit');
        }

        if ($('.ynab-grid-add-rows', '.ynab-grid').length) {
          this.attachWillInsertHandler('register/grid-add');
        }

        if ($('.ynab-grid-body-split.is-editing', '.ynab-grid').length) {
          this.attachWillInsertHandler('register/grid-sub-edit');
        }

        if ($('.ynab-grid-body-row.ynab-grid-footer', '.ynab-grid').length) {
          this.attachWillInsertHandler('register/grid-footer');
        }

        ynabToolKit.invokeFeature('AdjustableColumnWidths');
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!this.runningBalance.shouldInvoke()) {
          this.runningBalance.cleanup();
        }

        if (!this.checkNumbers.shouldInvoke()) {
          this.checkNumbers.cleanup();
        }

        if (!this.runningBalance.shouldInvoke() && !this.checkNumbers.shouldInvoke()) {
          return;
        }

        if (changedNodes.has('ynab-grid-body') || changedNodes.has('ynab-grid')) {
          this.invoke();
        }
      }
    }]);

    return AdditionalColumns;
  }(_feature.Feature);

  /***/
},
/* 9 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });

  var _observeListener = __webpack_require__(10);

  Object.defineProperty(exports, 'ObserveListener', {
    enumerable: true,
    get: function get() {
      return _observeListener.ObserveListener;
    }
  });

  var _routeChangeListener = __webpack_require__(11);

  Object.defineProperty(exports, 'RouteChangeListener', {
    enumerable: true,
    get: function get() {
      return _routeChangeListener.RouteChangeListener;
    }
  });

  /***/
},
/* 10 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var instance = null;

  var ObserveListener = exports.ObserveListener = function () {
    function ObserveListener() {
      var _this = this;

      _classCallCheck(this, ObserveListener);

      if (instance) {
        return instance;
      }

      this.features = [];

      var _MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
      var observer = new _MutationObserver(function (mutations) {
        _this.changedNodes = new Set();

        mutations.forEach(function (mutation) {
          var newNodes = mutation.target;
          var $nodes = $(newNodes);

          $nodes.each(function (index, element) {
            var nodeClass = $(element).attr('class');
            if (nodeClass) {
              _this.changedNodes.add(nodeClass.replace(/^ember-view /, ''));
            }
          });
        });

        // Now we are ready to feed the change digest to the
        // automatically setup feedChanges file/function
        if (_this.changedNodes.size > 0) {
          _this.emitChanges();
        }
      });

      // This finally says 'Watch for changes' and only needs to be called the one time
      observer.observe($('.ember-view.layout')[0], {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['class']
      });

      instance = this;
    }

    _createClass(ObserveListener, [{
      key: 'addFeature',
      value: function addFeature(feature) {
        if (this.features.indexOf(feature) === -1) {
          this.features.push(feature);
        }
      }
    }, {
      key: 'emitChanges',
      value: function emitChanges() {
        var _this2 = this;

        this.features.forEach(function (feature) {
          Ember.run.later(feature.observe.bind(feature, _this2.changedNodes), 0);
        });
      }
    }]);

    return ObserveListener;
  }();

  /***/
},
/* 11 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.RouteChangeListener = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _toolkit = __webpack_require__(2);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var instance = null;

  var RouteChangeListener = exports.RouteChangeListener = function () {
    function RouteChangeListener() {
      _classCallCheck(this, RouteChangeListener);

      if (instance) {
        return instance;
      }

      var routeChangeListener = this;
      routeChangeListener.features = [];

      var applicationController = (0, _toolkit.controllerLookup)('application');
      applicationController.reopen({
        onRouteChanged: Ember.observer('currentRouteName', // this will handle accounts -> budget and vise versa
        'budgetVersionId', // this will handle changing budgets
        'selectedAccountId', // this will handle switching around accounts
        'monthString', // this will handle changing which month of a budget you're looking at
        function (controller, changedProperty) {
          if (changedProperty === 'budgetVersionId') {
            Ember.run.scheduleOnce('afterRender', controller, 'emitBudgetRouteChange');
          } else {
            Ember.run.scheduleOnce('afterRender', controller, 'emitSameBudgetRouteChange');
          }
        }),

        emitSameBudgetRouteChange: function emitSameBudgetRouteChange() {
          var currentRoute = applicationController.get('currentRouteName');
          routeChangeListener.features.forEach(function (feature) {
            setTimeout(feature.onRouteChanged.bind(feature, currentRoute), 0);
          });
        },

        emitBudgetRouteChange: function emitBudgetRouteChange() {
          var currentRoute = applicationController.get('currentRouteName');
          routeChangeListener.features.forEach(function (feature) {
            setTimeout(feature.onBudgetChanged.bind(feature, currentRoute), 0);
          });
        }
      });

      instance = this;
    }

    _createClass(RouteChangeListener, [{
      key: 'addFeature',
      value: function addFeature(feature) {
        if (this.features.indexOf(feature) === -1) {
          this.features.push(feature);
        }
      }
    }]);

    return RouteChangeListener;
  }();

  /***/
},
/* 12 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var AdditionalColumnStub = exports.AdditionalColumnStub = function () {
    function AdditionalColumnStub() {
      _classCallCheck(this, AdditionalColumnStub);
    }

    _createClass(AdditionalColumnStub, [{
      key: "insertHeader",

      // Inserts the header for your additional column
      value: function insertHeader() {}

      // Should remove all additional column related elements from the page

    }, {
      key: "cleanup",
      value: function cleanup() {}

      // Can return a promise, will get called during the normal willInvoke cycle
      // of a feature.

    }, {
      key: "willInvoke",
      value: function willInvoke() {}

      // Should return a boolean that informs AdditionalColumns feature that it
      // is on a page that should recevie the new column.

    }, {
      key: "shouldInvoke",
      value: function shouldInvoke() {}

      // Called when one of the grid rows is getting inserted into the dom but
      // before it actually makes it into the dom. This should be doing the grunt
      // of the work.

    }, {
      key: "willInsertColumn",
      value: function willInsertColumn() {}

      // Called for all the rows that don't need the column data.

    }, {
      key: "willInsertDeadColumn",
      value: function willInsertDeadColumn() {}

      // this is really hacky but I'm not sure what else to do, most of these components
      // double render so the `willInsertElement` works for those but the add rows
      // and footer are weird. add-rows doesn't double render and will work every time
      // after the component has been cached but footer is _always_ a new component WutFace

    }, {
      key: "handleSingleRenderColumn",
      value: function handleSingleRenderColumn() {}
    }]);

    return AdditionalColumnStub;
  }();

  /***/
},
/* 13 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.RunningBalance = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var RunningBalance = exports.RunningBalance = function () {
    function RunningBalance() {
      _classCallCheck(this, RunningBalance);
    }

    _createClass(RunningBalance, [{
      key: 'willInvoke',
      value: function willInvoke() {
        return this.initializeRunningBalances();
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        var applicationController = toolkitHelper.controllerLookup('application');
        return applicationController.get('selectedAccountId') !== null;
      }
    }, {
      key: 'cleanup',
      value: function cleanup() {
        $('.ynab-grid-cell-toolkit-running-balance').remove();
      }
    }, {
      key: 'insertHeader',
      value: function insertHeader() {
        if ($('.ynab-grid-header .ynab-grid-cell-toolkit-running-balance').length) return;

        var $headerRow = $('.ynab-grid-header');
        var runningBalanceHeader = $('.ynab-grid-cell-inflow', $headerRow).clone();
        runningBalanceHeader.removeClass('ynab-grid-cell-inflow');
        runningBalanceHeader.addClass('ynab-grid-cell-toolkit-running-balance');
        runningBalanceHeader.text('RUNNING BALANCE').css('font-weight', 'normal');
        runningBalanceHeader.insertAfter($('.ynab-grid-cell-inflow', $headerRow));
        runningBalanceHeader.click(function (event) {
          event.preventDefault();
          event.stopPropagation();
          $('.ynab-grid-cell-date', $headerRow).click();
        });

        if ($('.ynab-grid-body .ynab-grid-body-row-top .ynab-grid-cell-toolkit-running-balance').length) return;
        var $topRow = $('.ynab-grid-body-row-top');
        var topRowRunningBalance = $('.ynab-grid-cell-inflow', $topRow).clone();
        topRowRunningBalance.removeClass('ynab-grid-cell-inflow');
        topRowRunningBalance.addClass('ynab-grid-cell-toolkit-running-balance');
        topRowRunningBalance.insertAfter($('.ynab-grid-cell-inflow', $topRow));
      }
    }, {
      key: 'handleSingleRenderColumn',
      value: function handleSingleRenderColumn($appendToRows) {
        $appendToRows.each(function (index, row) {
          if ($('.ynab-grid-cell-toolkit-running-balance', row).length === 0) {
            $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-running-balance">').insertAfter($('.ynab-grid-cell-inflow', row));
          }
        });
      }
    }, {
      key: 'willInsertColumn',
      value: function willInsertColumn() {
        var isSub = this.get('_debugContainerKey') === 'component:register/grid-sub';
        var isRow = this.get('_debugContainerKey') === 'component:register/grid-row';
        var isScheduled = this.get('_debugContainerKey') === 'component:register/grid-scheduled';
        var isRunningBalance = isSub || isRow || isScheduled;

        if (isRunningBalance) {
          var applicationController = toolkitHelper.controllerLookup('application');
          var selectedAccountId = applicationController.get('selectedAccountId');
          if (!selectedAccountId) {
            return;
          }

          var $currentRow = $(this.element);
          var currentRowRunningBalance = $('.ynab-grid-cell-inflow', $currentRow).clone();
          currentRowRunningBalance.removeClass('ynab-grid-cell-inflow');
          currentRowRunningBalance.addClass('ynab-grid-cell-toolkit-running-balance');

          var transaction = this.get('content');

          var runningBalance = transaction.__ynabToolKitRunningBalance;
          if (typeof runningBalance === 'undefined') {
            calculateRunningBalance(selectedAccountId);
            runningBalance = transaction.__ynabToolKitRunningBalance;
          }

          var currencySpan = $('.user-data', currentRowRunningBalance);
          if (runningBalance < 0) {
            currencySpan.addClass('user-data currency negative');
          } else if (runningBalance > 0) {
            currencySpan.addClass('user-data currency positive');
          } else {
            currencySpan.addClass('user-data currency zero');
          }

          if (transaction.get('parentEntityId') !== null) {
            currencySpan.text('');
          } else {
            currencySpan.text(ynabToolKit.shared.formatCurrency(runningBalance));
          }

          currentRowRunningBalance.insertAfter($('.ynab-grid-cell-inflow', $currentRow));
        } else {
          if ($('.ynab-grid-cell-toolkit-running-balance', this.element).length === 0) {
            $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-running-balance">').insertAfter($('.ynab-grid-cell-inflow', this.element));
          }
        }
      }
    }, {
      key: 'initializeRunningBalances',
      value: function initializeRunningBalances() {
        return ynab.YNABSharedLib.defaultInstance.entityManager.accountsCollection.forEach(function (account) {
          return ynab.YNABSharedLib.defaultInstance.getBudgetViewModel_AccountTransactionsViewModel(account.entityId).then(function (accountViewModel) {
            calculateRunningBalance(account.entityId);

            // can you believe it? YNAB has this really interestingly name field
            // on visibleTransactionDisplayItems that sounds exactly like what I need
            // if something changes in that list, you tell me about it, and I'll update
            // the running balance for the account make sure our users always see the fancy
            accountViewModel.get('visibleTransactionDisplayItems').addObserver('anyItemChangedCounter', function () {
              calculateRunningBalance(account.entityId);
            });
          });
        });
      }
    }]);

    return RunningBalance;
  }();

  // Using ._result here bcause we can guarantee that we've already invoked the
  // getBudgetViewModel_AccountTransactionsViewModel() function when we initialized


  function calculateRunningBalance(accountId) {
    var accountsController = toolkitHelper.controllerLookup('accounts');
    var accountViewModel = ynab.YNABSharedLib.defaultInstance.getBudgetViewModel_AccountTransactionsViewModel(accountId)._result;

    var transactions = accountViewModel.get('visibleTransactionDisplayItems');
    var sorted = transactions.slice().sort(function (a, b) {
      var propA = a.get('date');
      var propB = b.get('date');

      if (propA instanceof ynab.utilities.DateWithoutTime) propA = propA.getUTCTime();
      if (propB instanceof ynab.utilities.DateWithoutTime) propB = propB.getUTCTime();

      var res = Ember.compare(propA, propB);

      if (res === 0) {
        res = Ember.compare(a.getAmount(), b.getAmount());
        if (accountsController.get('sortAscending')) {
          return res;
        }

        return -res;
      }

      return res;
    });

    var runningBalance = 0;
    sorted.forEach(function (transaction) {
      if (transaction.get('parentEntityId') !== null) {
        transaction.__ynabToolKitRunningBalance = runningBalance;
        return;
      }

      if (transaction.get('inflow')) {
        runningBalance += transaction.get('inflow');
      } else if (transaction.get('outflow')) {
        runningBalance -= transaction.get('outflow');
      }

      transaction.__ynabToolKitRunningBalance = runningBalance;
    });
  }

  /***/
},
/* 14 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CheckNumbers = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  var CheckNumbers = exports.CheckNumbers = function () {
    function CheckNumbers() {
      _classCallCheck(this, CheckNumbers);
    }

    _createClass(CheckNumbers, [{
      key: 'insertHeader',
      value: function insertHeader() {
        if ($('.ynab-grid-header .ynab-grid-cell-toolkit-check-number').length) return;

        var $headerRow = $('.ynab-grid-header');
        var checkNumberHeader = $('.ynab-grid-cell-inflow', $headerRow).clone();
        checkNumberHeader.removeClass('ynab-grid-cell-inflow');
        checkNumberHeader.addClass('ynab-grid-cell-toolkit-check-number');
        checkNumberHeader.text('CHECK NUMBER').css('font-weight', 'normal');
        checkNumberHeader.insertAfter($('.ynab-grid-cell-memo', $headerRow));
        checkNumberHeader.click(function (event) {
          event.preventDefault();
          event.stopPropagation();
        });

        if ($('.ynab-grid-body .ynab-grid-body-row-top .ynab-grid-cell-toolkit-check-number').length) return;
        var $topRow = $('.ynab-grid-body-row-top');
        var topRowCheckNumber = $('.ynab-grid-cell-inflow', $topRow).clone();
        topRowCheckNumber.removeClass('ynab-grid-cell-inflow');
        topRowCheckNumber.addClass('ynab-grid-cell-toolkit-check-number');
        topRowCheckNumber.insertAfter($('.ynab-grid-cell-memo', $topRow));
      }
    }, {
      key: 'cleanup',
      value: function cleanup() {
        $('.ynab-grid-cell-toolkit-check-number').remove();
      }

      // Don't need to do any pre-processing for check-numbers...carry on now.

    }, {
      key: 'willInvoke',
      value: function willInvoke() {
        return;
      }

      // Should return a boolean that informs AdditionalColumns feature that it
      // is on a page that should recevie the new column.

    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('account') !== -1;
      }

      // Called when one of the grid rows is getting inserted into the dom but
      // before it actually makes it into the dom. This should be doing the grunt
      // of the work.

    }, {
      key: 'willInsertColumn',
      value: function willInsertColumn() {
        var isAddRow = this.get('_debugContainerKey') === 'component:register/grid-add';
        var isEditRow = this.get('_debugContainerKey') === 'component:register/grid-edit';
        var isGridRow = this.get('_debugContainerKey') === 'component:register/grid-row';
        if (isAddRow || isEditRow) {
          var $editingRow = $(this.element);
          var editingTransaction = this.get('content');
          var $inputBox = $('<input placeholder="check number">').addClass('accounts-text-field').addClass('ynab-grid-cell-toolkit-check-number-input').blur(function () {
            editingTransaction.set('checkNumber', $(this).val());
          });

          $inputBox.val(editingTransaction.get('checkNumber'));
          $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-check-number"><div>').append($inputBox).insertAfter($('.ynab-grid-cell-memo', $editingRow));
        } else if (isGridRow) {
          // view only column
          var $currentRow = $(this.element);
          var checkNumberCell = $('.ynab-grid-cell-memo', $currentRow).clone();
          checkNumberCell.removeClass('ynab-grid-cell-memo');
          checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');

          var transaction = this.get('content');
          checkNumberCell.text(transaction.get('checkNumber') || '');
          checkNumberCell.insertAfter($('.ynab-grid-cell-memo', $currentRow));
        } else {
          // dead column
          var _checkNumberCell = $('.ynab-grid-cell-memo', this.element).clone();
          _checkNumberCell.removeClass('ynab-grid-cell-memo');
          _checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');
          _checkNumberCell.insertAfter($('.ynab-grid-cell-memo', this.element));
          _checkNumberCell.empty();
        }
      }

      // this is really hacky but I'm not sure what else to do, most of these components
      // double render so the `willInsertElement` works for those but the add rows
      // and footer are weird. add-rows doesn't double render and will work every time
      // after the component has been cached but footer is _always_ a new component WutFace

    }, {
      key: 'handleSingleRenderColumn',
      value: function handleSingleRenderColumn($appendToRows, componentName) {
        if (componentName === 'register/grid-add') {
          var accountsController = ynabToolKit.shared.containerLookup('controller:accounts');
          var editingTransaction = accountsController.get('editingTransaction');
          var $inputBox = $('<input placeholder="check number">').addClass('accounts-text-field').addClass('ynab-grid-cell-toolkit-check-number-input').blur(function () {
            editingTransaction.set('checkNumber', $(this).val());
          });

          $inputBox.val(editingTransaction.get('checkNumber'));
          $('<div class="ynab-grid-cell ynab-grid-cell-toolkit-check-number"><div>').append($inputBox).insertAfter($('.ynab-grid-cell-memo', $appendToRows));

          return;
        }

        $appendToRows.each(function (index, row) {
          if ($('.ynab-grid-cell-toolkit-check-number', row).length === 0) {
            var checkNumberCell = $('.ynab-grid-cell-memo', row).clone();
            checkNumberCell.removeClass('ynab-grid-cell-memo');
            checkNumberCell.addClass('ynab-grid-cell-toolkit-check-number');
            checkNumberCell.insertAfter($('.ynab-grid-cell-memo', row));
            checkNumberCell.empty();
          }
        });
      }
    }]);

    return CheckNumbers;
  }();

  /***/
},
/* 15 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(16);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 16 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-cell-toolkit-running-balance {\n\ttext-align: right;\n\twidth: 10%;\n}\n\n.ynab-grid-cell-toolkit-check-number {\n\ttext-align: right;\n\twidth: 10%;\n}\n", ""]);

  // exports


  /***/
},
/* 17 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(18);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 18 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-cell-toolkit-running-balance span.negative {\n\tcolor: #d33c2d;\n\tfont-weight: bold;\n}", ""]);

  // exports


  /***/
},
/* 19 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.AdjustableColumnWidths = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var RESIZABLES = ['ynab-grid-cell-date', 'ynab-grid-cell-accountName', 'ynab-grid-cell-payeeName', 'ynab-grid-cell-subCategoryName', 'ynab-grid-cell-memo', 'ynab-grid-cell-toolkit-check-number', 'ynab-grid-cell-outflow', 'ynab-grid-cell-inflow', 'ynab-grid-cell-toolkit-running-balance'];

  var AdjustableColumnWidths = exports.AdjustableColumnWidths = function (_Feature) {
    _inherits(AdjustableColumnWidths, _Feature);

    function AdjustableColumnWidths() {
      var _ref;

      var _temp, _this, _ret;

      _classCallCheck(this, AdjustableColumnWidths);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = AdjustableColumnWidths.__proto__ || Object.getPrototypeOf(AdjustableColumnWidths)).call.apply(_ref, [this].concat(args))), _this), _this.elementWasDragged = false, _this.isMouseDown = false, _this.currentX = null, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(AdjustableColumnWidths, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(20);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return (0, _toolkit.getCurrentRouteName)().indexOf('account') !== -1;
      }
    }, {
      key: 'onMouseMove',
      value: function onMouseMove(event) {
        var _this2 = this;

        if (!this.isMouseDown) {
          return;
        }

        event.preventDefault();
        event.stopPropagation();

        Ember.run.debounce(this, function () {
          if (_this2.offTarget && !event.target.classList.contains('toolkit-draggable')) {
            return;
          }

          _this2.offTarget = false;
          var invertedDifference = _this2.currentX - event.clientX;
          var difference = invertedDifference * -1;

          var _getNeighborOf = _this2.getNeighborOf(_this2.currentResizableClass),
              isNeighborResizable = _getNeighborOf.isNeighborResizable,
              neighborCellName = _getNeighborOf.neighborCellName;

          if (!isNeighborResizable) {
            return;
          }

          var $elementsOfTypeNeighbor = $('.' + neighborCellName);
          var neighborWidth = $elementsOfTypeNeighbor.width();
          var newNeighborWidth = neighborWidth - difference;

          var $elementsOfTypeCurrentResizable = $('.' + _this2.currentResizableClass);
          var currentResizableWidth = $elementsOfTypeCurrentResizable.width();
          var newCurrentResizableWidth = currentResizableWidth + difference;

          if (newNeighborWidth < 50 || newCurrentResizableWidth < 50) {
            _this2.offTarget = true;
            return;
          }

          _this2.currentX = event.clientX;
          $elementsOfTypeCurrentResizable.width(newCurrentResizableWidth);
          (0, _toolkit.setToolkitStorageKey)('column-width-' + _this2.currentResizableClass, newCurrentResizableWidth);

          $elementsOfTypeNeighbor.width(newNeighborWidth);
          (0, _toolkit.setToolkitStorageKey)('column-width-' + neighborCellName, newNeighborWidth);
        }, 100);
      }
    }, {
      key: 'onMouseUp',
      value: function onMouseUp() {
        $('body').off('mousemove', this.bindOnMouseMove);
        $('body').off('mouseup', this.bindOnMouseUp);

        if (this.isMouseDown) {
          this.isMouseDown = false;
          this.elementWasDragged = true;
        }
      }
    }, {
      key: 'getNeighborOf',
      value: function getNeighborOf(neighborOf) {
        var $rightNeighbor = $('.' + neighborOf, '.ynab-grid-header').next();

        if (!$rightNeighbor.length) {
          return { isNeighborResizable: false };
        }

        var neighborCellName = $rightNeighbor.prop('class').match(/ynab-grid-cell.*/)[0];
        return {
          neighborCellName: neighborCellName,
          isNeighborResizable: RESIZABLES.some(function (className) {
            return className === neighborCellName;
          })
        };
      }
    }, {
      key: 'resetWidths',
      value: function resetWidths() {
        RESIZABLES.forEach(function (resizableClass) {
          $('.' + resizableClass).width('');
          (0, _toolkit.removeToolkitStorageKey)('column-width-' + resizableClass);
        });
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        var _this3 = this;

        if (!$('.toolkit-reset-widths').length) {
          $('<button class="toolkit-reset-widths button">Reset Column Widths</button>').click(this.resetWidths).insertAfter($('.accounts-toolbar-all-dates', '.accounts-toolbar-right'));
        }

        RESIZABLES.forEach(function (resizableClass) {
          var width = (0, _toolkit.getToolkitStorageKey)('column-width-' + resizableClass, 'number');
          if (width) {
            $('.' + resizableClass).width(width);
          }

          if (!_this3.getNeighborOf(resizableClass).isNeighborResizable) {
            return;
          }

          if ($('.' + resizableClass + ' .toolkit-draggable', '.ynab-grid-header').length) {
            return;
          }

          $('.' + resizableClass, '.ynab-grid-header').click(function (event) {
            if (_this3.elementWasDragged) {
              event.preventDefault();
              event.stopPropagation();
              _this3.elementWasDragged = false;
            }
          }).css({ position: 'relative' }).append($('<div class="toolkit-draggable"></div>').click(function (event) {
            return event.stopPropagation();
          }).mousedown(function (event) {
            _this3.isMouseDown = true;
            _this3.currentX = event.clientX;
            _this3.currentResizableClass = resizableClass;

            _this3.bindOnMouseMove = _this3.onMouseMove.bind(_this3);
            _this3.bindOnMouseUp = _this3.onMouseUp.bind(_this3);
            $('body').on('mousemove', _this3.bindOnMouseMove);
            $('body').on('mouseup', _this3.bindOnMouseUp);
          }));
        });
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) {
          return;
        }
        this.invoke();
      }
    }]);

    return AdjustableColumnWidths;
  }(_feature.Feature);

  /***/
},
/* 20 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(21);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 21 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".toolkit-draggable {\n  display: inline-block;\n  right: 0;\n  position: absolute;\n  background: transparent;\n  width: 4px;\n  height: inherit;\n  cursor: col-resize;\n}\n\n.toolkit-reset-widths {\n  padding-top: .4em;\n}\n", ""]);

  // exports


  /***/
},
/* 22 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CalendarFirstDay = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var CalendarFirstDay = exports.CalendarFirstDay = function (_Feature) {
    _inherits(CalendarFirstDay, _Feature);

    function CalendarFirstDay() {
      var _ref;

      var _temp, _this, _ret;

      _classCallCheck(this, CalendarFirstDay);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = CalendarFirstDay.__proto__ || Object.getPrototypeOf(CalendarFirstDay)).call.apply(_ref, [this].concat(args))), _this), _this.isCalendarOpen = false, _this.isReRendering = false, _temp), _possibleConstructorReturn(_this, _ret);
    }
    // Variables for tracking specific states


    _createClass(CalendarFirstDay, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return false;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        /* nothing to see here; move along */
      }
    }, {
      key: 'reRenderHeader',
      value: function reRenderHeader() {
        var shiftDays = this.shiftDays();
        // Shift the header items by number of days (only needs to happen once)
        for (var i = 0; i < shiftDays; i++) {
          var first = $('.accounts-calendar-weekdays').children().first();
          var last = $('.accounts-calendar-weekdays').children().last();
          first.insertAfter(last);
        }
        this.reRenderWeekdays();
      }
    }, {
      key: 'reRenderWeekdays',
      value: function reRenderWeekdays() {
        var shiftDays = this.shiftDays();

        // Remove all previously added shift elements
        $('.accounts-calendar-grid').find('.shift').remove();

        if ($('.accounts-calendar-empty').length >= shiftDays) {
          // Remove specific # of empty elements
          $('.accounts-calendar-empty').slice(-shiftDays).remove();
        } else {
          // Add 'shift' empty elements
          for (var j = 0; j < 7 - shiftDays; j++) {
            $('.accounts-calendar-grid').prepend('<li class="accounts-calendar-empty shift">&nbsp;</li>');
          }
        }
      }
    }, {
      key: 'shiftDays',
      value: function shiftDays() {
        return Number(this.settings.enabled);
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (changedNodes.has('ynab-u modal-account-calendar ember-view modal-overlay active')) {
          this.isCalendarOpen = true;
          this.reRenderHeader();
        } else if (changedNodes.has('ynab-u modal-account-calendar ember-view modal-overlay active closing')) {
          this.isCalendarOpen = false;
        } else if (changedNodes.has('accounts-calendar-grid') && !changedNodes.has('accounts-calendar-weekdays') && this.isCalendarOpen && !this.isReRendering) {
          this.isReRendering = true;
          this.reRenderWeekdays();
        } else if (this.isReRendering) {
          // It's now safe to start listening for changes on the calendar node
          this.isReRendering = false;
        }
      }
    }]);

    return CalendarFirstDay;
  }(_feature.Feature);

  /***/
},
/* 23 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ChangeEnterBehavior = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ChangeEnterBehavior = exports.ChangeEnterBehavior = function (_Feature) {
    _inherits(ChangeEnterBehavior, _Feature);

    function ChangeEnterBehavior() {
      _classCallCheck(this, ChangeEnterBehavior);

      return _possibleConstructorReturn(this, (ChangeEnterBehavior.__proto__ || Object.getPrototypeOf(ChangeEnterBehavior)).apply(this, arguments));
    }

    _createClass(ChangeEnterBehavior, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('account') !== -1 && $('.ynab-grid-body-row.is-adding').length;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        var $addRow = $('.ynab-grid-body-row.is-adding');
        var $memoInput = $('.ynab-grid-cell-memo input', $addRow);
        var $outflowInput = $('.ynab-grid-cell-outflow input', $addRow);
        var $inflowInput = $('.ynab-grid-cell-inflow input', $addRow);

        if (!$memoInput[0].getAttribute('data-toolkit-save-behavior')) {
          $memoInput[0].setAttribute('data-toolkit-save-behavior', true);
          $memoInput.keydown(this.applyNewEnterBehavior);
        }

        if (!$outflowInput[0].getAttribute('data-toolkit-save-behavior')) {
          $outflowInput[0].setAttribute('data-toolkit-save-behavior', true);
          $outflowInput.keydown(this.applyNewEnterBehavior);
        }

        if (!$inflowInput[0].getAttribute('data-toolkit-save-behavior')) {
          $inflowInput[0].setAttribute('data-toolkit-save-behavior', true);
          $inflowInput.keydown(this.applyNewEnterBehavior);
        }
      }
    }, {
      key: 'applyNewEnterBehavior',
      value: function applyNewEnterBehavior(event) {
        if (event.keyCode === 13) {
          event.preventDefault();
          event.stopPropagation();

          var $saveButton = $('.ynab-grid-actions-buttons .button.button-primary:not(.button-another)');
          $saveButton.click();
        }
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!changedNodes.has('ynab-grid-body')) return;

        if (this.shouldInvoke()) {
          this.invoke();
        }
      }
    }]);

    return ChangeEnterBehavior;
  }(_feature.Feature);

  /***/
},
/* 24 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ClearSelection = undefined;

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ClearSelection = exports.ClearSelection = function (_Feature) {
    _inherits(ClearSelection, _Feature);

    function ClearSelection() {
      var _ref;

      var _temp, _this, _ret;

      _classCallCheck(this, ClearSelection);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = ClearSelection.__proto__ || Object.getPrototypeOf(ClearSelection)).call.apply(_ref, [this].concat(args))), _this), _this.uncheckTransactions = function () {
        var accountsController = ynabToolKit.shared.containerLookup('controller:accounts');

        try {
          accountsController.get('areChecked').setEach('isChecked', 0);
          var gridHeader = ynabToolKit.shared.getEmberView($('.ynab-grid-header').attr('id'));
          gridHeader.childViews[0].set('isChecked', false);
          accountsController.send('closeModal');
        } catch (e) {
          accountsController.send('closeModal');
          ynabToolKit.shared.showFeatureErrorModal('Clear Selection');
        }
      }, _this.observe = function (changedNodes) {
        if (changedNodes.has('ynab-u modal-popup modal-account-edit-transaction-list ember-view modal-overlay active')) {
          _this.invoke();
        }
      }, _this.invoke = function () {
        var menuText = ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.accountsClearSelection'] || 'Clear Selection';

        // Note that ${menuText} was intentionally placed on the same line as the <i> tag to
        // prevent the leading space that occurs as a result of using a multi-line string.
        // Using a dedent function would allow it to be placed on its own line which would be
        // more natural.
        //
        // The second <li> functions as a separator on the menu after the feature menu item.
        $('.modal-account-edit-transaction-list .modal-list').prepend($('<li>\n            <button class="button-list ynab-toolkit-clear-selection">\n              <i class="flaticon stroke minus-2"></i>' + menuText + '\n            </button>\n          </li>\n          <li><hr /><li>').click(function () {
          _this.uncheckTransactions();
        }));
      }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return ClearSelection;
  }(_feature.Feature);

  /***/
},
/* 25 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CustomFlagNames = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var flags = void 0;
  var redFlagLabel = void 0;
  var blueFlagLabel = void 0;
  var orangeFlagLabel = void 0;
  var yellowFlagLabel = void 0;
  var greenFlagLabel = void 0;
  var purpleFlagLabel = void 0;

  var CustomFlagNames = exports.CustomFlagNames = function (_Feature) {
    _inherits(CustomFlagNames, _Feature);

    function CustomFlagNames() {
      _classCallCheck(this, CustomFlagNames);

      var _this = _possibleConstructorReturn(this, (CustomFlagNames.__proto__ || Object.getPrototypeOf(CustomFlagNames)).call(this));

      if (!toolkitHelper.getToolkitStorageKey('flags')) {
        _this.storeDefaultFlags();
      }
      if (typeof flags === 'undefined') {
        flags = JSON.parse(toolkitHelper.getToolkitStorageKey('flags'));
        _this.updateFlagLabels();
      }
      return _this;
    }

    _createClass(CustomFlagNames, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('account') !== -1;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        $('.ynab-grid-cell-flag .ynab-flag-red').parent().attr('title', redFlagLabel);
        $('.ynab-grid-cell-flag .ynab-flag-blue').parent().attr('title', blueFlagLabel);
        $('.ynab-grid-cell-flag .ynab-flag-orange').parent().attr('title', orangeFlagLabel);
        $('.ynab-grid-cell-flag .ynab-flag-yellow').parent().attr('title', yellowFlagLabel);
        $('.ynab-grid-cell-flag .ynab-flag-green').parent().attr('title', greenFlagLabel);
        $('.ynab-grid-cell-flag .ynab-flag-purple').parent().attr('title', purpleFlagLabel);
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!this.shouldInvoke()) return;

        if (changedNodes.has('layout user-logged-in') || changedNodes.has('ynab-grid-body')) {
          this.invoke();
        }

        if (changedNodes.has('ynab-u modal-popup modal-account-flags ember-view modal-overlay active')) {
          $('.ynab-flag-red .label, .ynab-flag-red .label-bg').text(redFlagLabel);
          $('.ynab-flag-blue .label, .ynab-flag-blue .label-bg').text(blueFlagLabel);
          $('.ynab-flag-orange .label, .ynab-flag-orange .label-bg').text(orangeFlagLabel);
          $('.ynab-flag-yellow .label, .ynab-flag-yellow .label-bg').text(yellowFlagLabel);
          $('.ynab-flag-green .label, .ynab-flag-green .label-bg').text(greenFlagLabel);
          $('.ynab-flag-purple .label, .ynab-flag-purple .label-bg').text(purpleFlagLabel);

          $('.modal-account-flags .modal').css({ height: '22em' }).append($('<div>', { id: 'account-flags-actions' }).css({ padding: '0 .3em' }).append($('<button>', { id: 'flags-edit', class: 'button button-primary' }).append('Edit ').append($('<i>', { class: 'flaticon stroke compose-3' }))));

          this.addEventListeners();
        }
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;

        this.invoke();
      }
    }, {
      key: 'addEventListeners',
      value: function addEventListeners() {
        var $this = this;
        $('#flags-edit').click(function () {
          $('.modal-account-flags .modal-list').empty();

          for (var key in flags) {
            var flag = flags[key];

            $('.modal-account-flags .modal-list').append($('<li>').append($('<input>', { id: key, type: 'text', class: 'flag-input', value: flag.label, placeholder: flag.label }).css({ color: '#fff', fill: flag.color, 'background-color': flag.color, height: 30, padding: '0 .7em', 'margin-bottom': '.3em', border: 'none' })));
          }

          $('#account-flags-actions').empty();

          $('#account-flags-actions').append($('<button>', { id: 'flags-close', class: 'button button-primary' }).append('Ok ').append($('<i>', { class: 'flaticon stroke checkmark-2' })));

          $('input.flag-input').focus(function () {
            $(this).css({
              color: '#000'
            });
          });

          $('input.flag-input').blur(function () {
            $(this).css({
              color: '#fff'
            });
            $this.saveFlag($(this));
          });

          $('#flags-close').click(function () {
            $('.modal-overlay').click();
          });
        });
      }
    }, {
      key: 'saveFlag',
      value: function saveFlag(flag) {
        if (flag.attr('placeholder') !== flag.val()) {
          var key = flag.attr('id');

          flags[key].label = flag.val();
          toolkitHelper.setToolkitStorageKey('flags', JSON.stringify(flags));

          this.updateFlagLabels();
          this.invoke();
        }
      }
    }, {
      key: 'updateFlagLabels',
      value: function updateFlagLabels() {
        redFlagLabel = flags.red.label;
        blueFlagLabel = flags.blue.label;
        orangeFlagLabel = flags.orange.label;
        yellowFlagLabel = flags.yellow.label;
        greenFlagLabel = flags.green.label;
        purpleFlagLabel = flags.purple.label;
      }
    }, {
      key: 'storeDefaultFlags',
      value: function storeDefaultFlags() {
        var flagsJSON = {
          red: {
            label: 'Red',
            color: '#d43d2e'
          },
          orange: {
            label: 'Orange',
            color: '#ff7b00'
          },
          yellow: {
            label: 'Yellow',
            color: '#f8e136'
          },
          green: {
            label: 'Green',
            color: '#9ac234'
          },
          blue: {
            label: 'Blue',
            color: '#0082cb'
          },
          purple: {
            label: 'Purple',
            color: '#9384b7'
          }
        };
        toolkitHelper.setToolkitStorageKey('flags', JSON.stringify(flagsJSON));
      }
    }]);

    return CustomFlagNames;
  }(_feature.Feature);

  /***/
},
/* 26 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.AccountsEmphasizedOutflows = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var AccountsEmphasizedOutflows = exports.AccountsEmphasizedOutflows = function (_Feature) {
    _inherits(AccountsEmphasizedOutflows, _Feature);

    function AccountsEmphasizedOutflows() {
      _classCallCheck(this, AccountsEmphasizedOutflows);

      return _possibleConstructorReturn(this, (AccountsEmphasizedOutflows.__proto__ || Object.getPrototypeOf(AccountsEmphasizedOutflows)).apply(this, arguments));
    }

    _createClass(AccountsEmphasizedOutflows, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(27);
      }
    }]);

    return AccountsEmphasizedOutflows;
  }(_feature.Feature);

  /***/
},
/* 27 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(28);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 28 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-cell-outflow .currency::before {\n\tcontent: \"(\";\n}\n\n.ynab-grid-cell-outflow .currency::after {\n\tcontent: \")\";\n}\n\n.ynab-grid-cell-outflow .currency {\n\tcolor: #c00;\n}\n\n.ynab-grid-body-row.is-checked .ynab-grid-cell-outflow .currency {\n\tcolor: #ff4b2b;\n\tfont-weight: bold;\n}\n", ""]);

  // exports


  /***/
},
/* 29 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.LargerClickableIcons = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var LargerClickableIcons = exports.LargerClickableIcons = function (_Feature) {
    _inherits(LargerClickableIcons, _Feature);

    function LargerClickableIcons() {
      _classCallCheck(this, LargerClickableIcons);

      return _possibleConstructorReturn(this, (LargerClickableIcons.__proto__ || Object.getPrototypeOf(LargerClickableIcons)).apply(this, arguments));
    }

    _createClass(LargerClickableIcons, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(30);
      }
    }]);

    return LargerClickableIcons;
  }(_feature.Feature);

  /***/
},
/* 30 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(31);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 31 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-body-row .ynab-grid-cell-cleared .flaticon {\n\twidth: 100%;\n\theight: 22px;\n}", ""]);

  // exports


  /***/
},
/* 32 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.RowHeight = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var compactHeight = 27;
  var slimHeight = 22;

  var RowHeight = exports.RowHeight = function (_Feature) {
    _inherits(RowHeight, _Feature);

    function RowHeight() {
      _classCallCheck(this, RowHeight);

      return _possibleConstructorReturn(this, (RowHeight.__proto__ || Object.getPrototypeOf(RowHeight)).apply(this, arguments));
    }

    _createClass(RowHeight, [{
      key: 'injectCSS',
      value: function injectCSS() {
        var css = __webpack_require__(33);

        if (this.settings.enabled === '1') {
          css += __webpack_require__(35);
        } else if (this.settings.enabled === '2') {
          css += __webpack_require__(37);
        }

        return css;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        // If the activity-transaction-link feature is not active we don't want to adjust the
        // record height because doing so causes scrolling to be jumpier than usual. If the
        // activity-transaction-link feature is active we do need to set the record height
        // because it uses the value to scroll the "selected transaction" to the top of the
        // register.
        if (ynabToolKit.options.ActivityTransactionLink) {
          var ynabGridContainer = (0, _toolkit.getEmberView)($('.ynab-grid-container').attr('id'));

          // Will be undefined when YNAB is loaded going directly to the budget screen.
          if (typeof ynabGridContainer !== 'undefined') {
            var recordHeight = ynabGridContainer.get('recordHeight');

            // The second check is to minimize the times that recordHeight is changed because
            // each time it's changed YNAB reacts to it and that contributes to the scrolling
            // jumpyness.
            if (ynabToolKit.options.accountsRowHeight === '1' && recordHeight !== compactHeight) {
              ynabGridContainer.set('recordHeight', compactHeight);
            } else if (ynabToolKit.options.accountsRowHeight === '2' && recordHeight !== slimHeight) {
              ynabGridContainer.set('recordHeight', slimHeight);
            }
          }

          // Add our class so our CSS can take effect.
          $('.ynab-grid-body-row-top > .ynab-grid-cell').addClass('toolkit-ynab-grid-cell');
        }
      }

      // We always want to invoke so we can run on page load and such.

    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return true;
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (changedNodes.has('ynab-grid-body')) {
          this.invoke();
        }
      }
    }]);

    return RowHeight;
  }(_feature.Feature);

  /***/
},
/* 33 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(34);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 34 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".toolkit-modal-item-hide-image {\n    visibility: hidden;\n}\n\n.modal-adjust-row-height {\n    background-color: transparent;\n}\n\n.modal-adjust-row-height .modal {\n    padding:.3em 0;\n    width:10.5em;\n    font-size:.9em;\n}\n", ""]);

  // exports


  /***/
},
/* 35 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(36);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 36 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-header-cell {\n    height: 1.6em !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell {\n\theight: 1.6em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n\tpadding-bottom: 0.1em !important;\n\t/*font-size: .850em !important;*/\n}\n\n.toolkit-ynab-grid-cell {\n\theight: 0px !important;\n}\n\n.ynab-grid-body-row {\n\theight: 1.8em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell-checkbox\n.ynab-grid-cell-notification\n.ynab-grid-cell-flag\n.ynab-grid-cell-accountName\n.ynab-grid-cell-date\n.ynab-grid-cell-payeeName\n.ynab-grid-cell-subCategoryName\n.ynab-grid-cell-memo\n.ynab-grid-cell-outflow\n.ynab-grid-cell-inflow\n.ynab-grid-cell-cleared\n{\n\theight: 1.8em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 37 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(38);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 38 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynab-grid-header-cell {\n    height: 1.2em !important;\n\tpadding-top: 0.1em !important;\n}\n\n.ynab-grid-cell {\n\theight: 1.2em !important;\n\ttop: 0 !important;\n\tpadding-top: 0 !important;\n\tpadding-bottom: 0 !important;\n\tfont-size: .90em !important;\n}\n\n/*.ynab-grid-body-row-top.ynab-grid-cell {*/\n.toolkit-ynab-grid-cell {\n\theight: 0px !important;\n}\n\n.ynab-grid-body-row {\n\theight: 1.4em !important;\n\ttop: 0 !important;\n\tpadding-top: 0 !important;\n}\n\n.ynab-grid-cell-checkbox\n.ynab-grid-cell-notification\n.ynab-grid-cell-flag\n.ynab-grid-cell-accountName\n.ynab-grid-cell-date\n.ynab-grid-cell-payeeName\n.ynab-grid-cell-subCategoryName\n.ynab-grid-cell-memo\n.ynab-grid-cell-outflow\n.ynab-grid-cell-inflow\n.ynab-grid-cell-cleared\n{\n\theight: 1.4em !important;\n\ttop: 0 !important;\n\tpadding-top: 0.1em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 39 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ShowCategoryBalance = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ShowCategoryBalance = exports.ShowCategoryBalance = function (_Feature) {
    _inherits(ShowCategoryBalance, _Feature);

    function ShowCategoryBalance() {
      _classCallCheck(this, ShowCategoryBalance);

      return _possibleConstructorReturn(this, (ShowCategoryBalance.__proto__ || Object.getPrototypeOf(ShowCategoryBalance)).apply(this, arguments));
    }

    _createClass(ShowCategoryBalance, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('account') !== -1;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        toolkitHelper.getAllBudgetMonthsViewModel().then(function (allBudgetMonthsViewModel) {
          var subCategoryCalculations = allBudgetMonthsViewModel.get('monthlySubCategoryBudgetCalculationsCollection');
          var categoryLookupPrefix = 'mcbc/' + toolkitHelper.getCurrentDate('YYYY-MM');

          var GridSubComponent = toolkitHelper.componentLookup('register/grid-sub');
          GridSubComponent.constructor.reopen({
            didRender: function didRender() {
              _didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
            }
          });

          var GridRowComponent = toolkitHelper.componentLookup('register/grid-row');
          GridRowComponent.constructor.reopen({
            didRender: function didRender() {
              _didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
            }
          });

          var GridScheduledComponent = toolkitHelper.componentLookup('register/grid-scheduled');
          GridScheduledComponent.constructor.reopen({
            didRender: function didRender() {
              _didRender.call(this, subCategoryCalculations, categoryLookupPrefix);
            }
          });
        });
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;

        this.invoke();
      }
    }]);

    return ShowCategoryBalance;
  }(_feature.Feature);

  function _didRender(subCategoryCalculations, categoryLookupPrefix) {
    var element = this.get('element');
    var subCategoryId = this.get('content.subCategoryId');
    var budgetData = subCategoryCalculations.findItemByEntityId(categoryLookupPrefix + '/' + subCategoryId);

    // if there's no budget data (could be an income/credit category) skip it.
    if (!budgetData) return;

    var title = $('.ynab-grid-cell-subCategoryName', element).attr('title');
    var newTitle = title + ' (Balance: ' + toolkitHelper.formatCurrency(budgetData.get('balance')) + ')';
    $('.ynab-grid-cell-subCategoryName', element).attr('title', newTitle);
  }

  /***/
},
/* 40 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SplitKeyboardShortcut = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var BUDGET_CATEGORIES_DROPDOWN_NODE = 'ynab-u modal-popup modal-account-dropdown modal-account-categories ember-view modal-overlay active';

  var SplitKeyboardShortcut = exports.SplitKeyboardShortcut = function (_Feature) {
    _inherits(SplitKeyboardShortcut, _Feature);

    function SplitKeyboardShortcut() {
      _classCallCheck(this, SplitKeyboardShortcut);

      return _possibleConstructorReturn(this, (SplitKeyboardShortcut.__proto__ || Object.getPrototypeOf(SplitKeyboardShortcut)).apply(this, arguments));
    }

    _createClass(SplitKeyboardShortcut, [{
      key: 'observe',
      value: function observe(changedNodes) {
        if ((0, _toolkit.getCurrentRouteName)().indexOf('account') !== -1) {
          if (changedNodes.has(BUDGET_CATEGORIES_DROPDOWN_NODE)) {
            var splitButton = $('.button.button-primary.modal-account-categories-split-transaction');

            // return if we are already inside a split subtransaction
            if (splitButton.length < 1) return false;

            var splitIcon = splitButton.html();
            var categoryList = $('.modal-account-categories .modal-list');
            var liElement = $('<li class="user-data">\n                              <button class="button-list">\n                                <div class="modal-account-categories-category" title="Split Transaction">\n                                  <span class="modal-account-categories-category-name"></span>\n                                </div>\n                              </button>\n                            </li>');

            liElement.find('.modal-account-categories-category-name').html(splitIcon);
            categoryList.append('<li class="user-data"><strong class="modal-account-categories-section-item">Actions:</strong></li>');
            categoryList.append(liElement);

            $('.ynab-grid-cell-subCategoryName input').on('keydown', function (e) {
              if (e.which === 13 || e.which === 9) {
                // Enter or Tab
                if (liElement.find('.button-list').hasClass('is-highlighted')) {
                  e.preventDefault();
                  splitButton.click();
                }
              }
            }).on('keyup', function () {
              var categoryInputString = new RegExp('^' + $(this).val());
              if (categoryInputString.test('split') && categoryList.find('.no-button').length === 1) {
                // highlight new split button if input contains part of
                // 'split' and there are no other categories available
                liElement.find('.button-list').addClass('is-highlighted');
              } else {
                liElement.find('.button-list').removeClass('is-highlighted');
              }
            });

            liElement.on('click', function () {
              splitButton.click();
            });
          }
        }
      }
    }]);

    return SplitKeyboardShortcut;
  }(_feature.Feature);

  /***/
},
/* 41 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.AccountsStripedRows = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var AccountsStripedRows = exports.AccountsStripedRows = function (_Feature) {
    _inherits(AccountsStripedRows, _Feature);

    function AccountsStripedRows() {
      _classCallCheck(this, AccountsStripedRows);

      return _possibleConstructorReturn(this, (AccountsStripedRows.__proto__ || Object.getPrototypeOf(AccountsStripedRows)).apply(this, arguments));
    }

    _createClass(AccountsStripedRows, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(42);
      }
    }]);

    return AccountsStripedRows;
  }(_feature.Feature);

  /***/
},
/* 42 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(43);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 43 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "/* Maybe this should play better with reconciled rows that don't have a background-color */\n.ynab-grid .ynab-grid-body-row:nth-of-type(even):not(.is-scheduled):not(.is-checked):not(.is-editing):not(.ynab-grid-body-empty):not(.ynab-grid-actions) {\n\tbackground-color: #fafafa;\n}\n", ""]);

  // exports


  /***/
},
/* 44 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ActivityTransactionLink = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ActivityTransactionLink = exports.ActivityTransactionLink = function (_Feature) {
    _inherits(ActivityTransactionLink, _Feature);

    function ActivityTransactionLink() {
      var _ref;

      var _temp, _this, _ret;

      _classCallCheck(this, ActivityTransactionLink);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = ActivityTransactionLink.__proto__ || Object.getPrototypeOf(ActivityTransactionLink)).call.apply(_ref, [this].concat(args))), _this), _this.selectedTransaction = null, _this.waitingForAccountsPage = false, _this.invoke = function () {
        $('.budget-activity').each(function (index, row) {
          $(row).addClass('toolkit-activity-row');

          $(row).on('click', function () {
            var selectedTransEmberId = $(row).attr('id');
            var emberView = ynabToolKit.shared.getEmberView(selectedTransEmberId);
            _this.selectedTransaction = emberView.get('transaction');
            $('.nav-account-name[title="' + _this.selectedTransaction.get('accountName') + '"]').trigger('click');
            _this.waitingForAccountsPage = true;
          });
        });
      }, _this.findTransactionIndex = function (contentResults) {
        var entityId = _this.selectedTransaction.get('parentEntityId') || _this.selectedTransaction.get('entityId');
        var transactionIndex = 0;

        for (var i = 0; i < contentResults.length; i++, transactionIndex++) {
          var currentTransaction = contentResults[i];

          if (contentResults[i].get('entityId') === entityId) {
            _this.selectedTransaction = currentTransaction;
            return transactionIndex;
          }
        }

        return -1;
      }, _this.resetFiltersAndShowSelectedTransaction = function (accountsController) {
        function getTransactionIndex() {
          accountsController.removeObserver('contentResults', getTransactionIndex);
          var contentResults = accountsController.get('contentResults');
          var transactionIndex = this.findTransactionIndex(contentResults);
          this.showSelectedTransaction(accountsController, contentResults, transactionIndex);
        }

        accountsController.addObserver('contentResults', getTransactionIndex);
        accountsController.filters.resetFilters();
      }, _this.findSelectedTransaction = function () {
        var accountsController = ynabToolKit.shared.containerLookup('controller:accounts');
        var contentResults = accountsController.get('contentResults');
        var transactionIndex = _this.findTransactionIndex(contentResults);

        if (transactionIndex === -1) {
          _this.resetFiltersAndShowSelectedTransaction(accountsController);
        } else {
          _this.showSelectedTransaction(accountsController, contentResults, transactionIndex);
        }
      }, _this.showSelectedTransaction = function (accountsController, contentResults, transactionIndex) {
        var ynabGrid = ynabToolKit.shared.getEmberView($('.ynab-grid').attr('id'));
        var ynabGridContainer = ynabToolKit.shared.getEmberView($('.ynab-grid-container').attr('id'));
        var recordHeight = ynabGridContainer.get('recordHeight');

        Ember.run.later(function () {
          var skipSplits = ynabToolKit.options.toggleSplits && ynabToolKit.toggleSplits.setting === 'hide';
          var transactionScrollTo = recordHeight * transactionIndex;

          $(ynabGridContainer.element).scrollTop(transactionScrollTo);

          // if the toggle splits feature is enabled and we're hiding splits, then we need to recalculate
          // the actual scroll position of the transaction we're linking to.
          if (skipSplits) {
            Ember.run.later(function () {
              var newIndex = transactionIndex;
              for (var i = ynabGridContainer.get('displayStart'); i < transactionIndex; i++) {
                if (contentResults[i].get('parentEntityId')) {
                  newIndex--;
                }
              }

              // there is a weird interaction with this feature and the toggle splits (i think) that causes
              // the transaction to still be hidden (just out of view at viewable transaction - 1). Unfortunately
              // getting that transaction isn't as simple as scrolling one more transaction so we're going
              // to scroll 5 more transactions. this isn't perfect, it's as magic number as it gets but it works until
              // i can pinpoint the actual issue here.
              var newTransactionScrollTo = recordHeight * (newIndex - 5);
              ynabGrid.uncheckAllBut(_this.selectedTransaction);
              $(ynabGridContainer.element).scrollTop(newTransactionScrollTo);
            }, 250);
          } else {
            ynabGrid.uncheckAllBut(_this.selectedTransaction);
          }
        }, 250);
      }, _this.observe = function (changedNodes) {
        if (changedNodes.has('ynab-u modal-popup modal-budget-activity ember-view modal-overlay active')) {
          _this.invoke();
        }

        if (_this.waitingForAccountsPage && changedNodes.has('ynab-grid-body')) {
          _this.waitingForAccountsPage = false;
          Ember.run.later(_this.findSelectedTransaction, 250);
        }
      }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(ActivityTransactionLink, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(45);
      }

      // find the parent entity if the selectedTransaction has one.

    }]);

    return ActivityTransactionLink;
  }(_feature.Feature);

  /***/
},
/* 45 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(46);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 46 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".toolkit-activity-row {\n\tcursor: pointer;\n}\n\n.toolkit-activity-row:hover {\n\tbackground: #DFE4E9\n}", ""]);

  // exports


  /***/
},
/* 47 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.BudgetBalanceToZero = undefined;

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var BudgetBalanceToZero = exports.BudgetBalanceToZero = function (_Feature) {
    _inherits(BudgetBalanceToZero, _Feature);

    function BudgetBalanceToZero() {
      var _ref;

      var _temp, _this, _ret;

      _classCallCheck(this, BudgetBalanceToZero);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = BudgetBalanceToZero.__proto__ || Object.getPrototypeOf(BudgetBalanceToZero)).call.apply(_ref, [this].concat(args))), _this), _this.attachedObserver = false, _this.budgetView = null, _this.shouldInvoke = function () {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1;
      }, _this.invoke = function () {
        if (!_this.attachedObserver) {
          _this.addBudgetVersionIdObserver();
          _this.attachedObserver = true;
        }

        var categories = _this.getCategories();
        var categoryName = _this.getInspectorName();
        var masterCategoryViewId = $('ul.is-checked').prevAll('ul.is-master-category').attr('id');

        if (masterCategoryViewId) {
          var masterCategory = ynabToolKit.shared.getEmberView(masterCategoryViewId).get('data');
          var masterCategoryId = masterCategory.get('categoryId');

          categories.forEach(function (category) {
            if (category.name === categoryName && category.masterCategoryId === masterCategoryId) {
              _this.updateInspectorButton(category);

              return false;
            }
          });
        }
      }, _this.observe = function (changedNodes) {
        if (_this.shouldInvoke() && (changedNodes.has('inspector-quick-budget') || changedNodes.has('budget-inspector-default'))) {
          _this.invoke();
        }
      }, _this.addBudgetVersionIdObserver = function () {
        var resetBudgetView = function resetBudgetView() {
          _this.budgetView = null;
        };

        var applicationController = ynabToolKit.shared.containerLookup('controller:application');
        applicationController.addObserver('budgetVersionId', function () {
          Ember.run.scheduleOnce('afterRender', this, resetBudgetView);
        });
      }, _this.getCategories = function () {
        // After using Budget Quick Switch, budgetView needs to be reset to the new budget. The try catch construct is necessary
        // because this function can be called several times during the budget switch process.
        if (_this.budgetView === null) {
          try {
            _this.budgetView = ynab.YNABSharedLib.getBudgetViewModel_AllBudgetMonthsViewModel()._result;
          } catch (e) {
            return;
          }
        }

        var categories = [];
        var masterCats = _this.budgetView.categoriesViewModel.masterCategoriesCollection._internalDataArray;
        var masterCategories = masterCats.filter(function (category) {
          return category.internalName === null;
        });

        masterCategories.forEach(function (category) {
          var accounts = _this.budgetView.categoriesViewModel.subCategoriesCollection.findItemsByMasterCategoryId(category.entityId);

          Array.prototype.push.apply(categories, accounts);
        });

        return categories;
      }, _this.updateInspectorButton = function (f) {
        var amount = _this.getBudgetAmount(f);
        var fAmount = ynabToolKit.shared.formatCurrency(amount);
        var existingButton = $('.toolkit-balance-to-zero');

        /* check for positive amounts */
        var positive = ynab.unformat(amount) > 0 ? '+' : '';
        var instance = _this;

        if (existingButton.length) {
          existingButton.empty().append(ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.balanceToZero'] || 'Balance to ' + ynabToolKit.shared.formatCurrency('0') + ': ').append(' ' + positive).append($('<strong>', { class: 'user-data', title: fAmount }).append(ynabToolKit.shared.appendFormattedCurrencyHtml($('<span>', { class: 'user-data currency zero' }), amount))).data('name', f.name).data('amount', amount);
        } else {
          var button = $('<a>', { class: 'budget-inspector-button toolkit-balance-to-zero' }).css({ 'text-align': 'center', 'line-height': '30px', display: 'block', cursor: 'pointer' }).data('name', f.name).data('amount', amount).click(function () {
            instance.updateBudgetedBalance($(this).data('name'), $(this).data('amount'));
          }).append(ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.balanceToZero'] || 'Balance to ' + ynabToolKit.shared.formatCurrency('0') + ': ').append(' ' + positive).append($('<strong>', { class: 'user-data', title: fAmount }).append(ynabToolKit.shared.appendFormattedCurrencyHtml($('<span>', { class: 'user-data currency zero' }), amount)));

          $('.inspector-quick-budget').append(button);
        }
      }, _this.updateBudgetedBalance = function (name, difference) {
        // eslint-disable-next-line no-alert
        if (ynabToolKit.options.warnOnQuickBudget && !confirm('Are you sure you want to do this?')) {
          return;
        }

        var categories = $('.is-sub-category.is-checked');

        $(categories).each(function () {
          var accountName = $(this).find('.budget-table-cell-name div.button-truncate').prop('title').match(/.[^\n]*/)[0];

          if (accountName === name) {
            var input = $(this).find('.budget-table-cell-budgeted div.currency-input').click().find('input');

            var oldValue = input.val();

            oldValue = ynab.unformat(oldValue);
            difference = ynab.unformat(ynab.convertFromMilliDollars(difference)); // YNAB stores currency values * 1000
            var newValue = oldValue + difference;

            $(input).val(ynab.YNABSharedLib.currencyFormatter.format(ynab.convertToMilliDollars(newValue)));

            if (!ynabToolKit.options.warnOnQuickBudget) {
              // only seems to work if the confirmation doesn't pop up?
              // haven't figured out a way to properly blur otherwise
              input.blur();
            }
          }
        });
      }, _this.getInspectorName = function () {
        return $('.inspector-category-name.user-data').text().trim();
      }, _this.getBudgetAmount = function (f) {
        var currentMonth = moment(ynabToolKit.shared.parseSelectedMonth()).format('YYYY-MM');
        var monthlyBudget = _this.budgetView.monthlySubCategoryBudgetCalculationsCollection.findItemByEntityId('mcbc/' + currentMonth + '/' + f.entityId);

        return monthlyBudget.balance * -1;
      }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return BudgetBalanceToZero;
  }(_feature.Feature);

  /***/
},
/* 48 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CategoryActivityCopy = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var CategoryActivityCopy = exports.CategoryActivityCopy = function (_Feature) {
    _inherits(CategoryActivityCopy, _Feature);

    function CategoryActivityCopy() {
      _classCallCheck(this, CategoryActivityCopy);

      return _possibleConstructorReturn(this, (CategoryActivityCopy.__proto__ || Object.getPrototypeOf(CategoryActivityCopy)).apply(this, arguments));
    }

    _createClass(CategoryActivityCopy, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        $('.modal-actions > .button-primary').clone().attr('id', 'toolkit-copy-button').insertAfter('.modal-actions > .button-primary').on('click', this.categoryActivityCopy);

        var childCache = $('#toolkit-copy-button').children();
        $('#toolkit-copy-button').text('Copy Transactions').append(childCache);
        $('#toolkit-copy-button > .flaticon').toggleClass('checkmark-2 copy').css('margin-left', '3px');
      }
    }, {
      key: 'categoryActivityCopy',
      value: function categoryActivityCopy() {
        var budgetController = toolkitHelper.controllerLookup('budget');
        var activityTransactions = budgetController.get('selectedActivityTransactions');
        var activities = activityTransactions.map(function (transaction) {
          return {
            Account: transaction.get('accountName'),
            Date: ynab.formatDateLong(transaction.get('date')),
            Category: transaction.get('subCategoryNameWrapped'),
            Memo: transaction.get('memo'),
            Amount: ynab.formatCurrency(transaction.get('amount'))
          };
        });

        var replacer = function replacer(key, value) {
          return value === null ? '' : value;
        };
        var header = Object.keys(activities[0]);
        var csv = activities.map(function (row) {
          return header.map(function (fieldName) {
            return JSON.stringify(row[fieldName], replacer);
          }).join('\t');
        });
        csv.unshift(header.join('\t'));
        csv = csv.join('\r\n');
        var $temp = $('<textarea style="position:absolute; left: -9999px; top: 50px;"/>');
        $('body').append($temp);
        $temp.val(csv).select();
        document.execCommand('copy');
        $temp.remove();
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!this.shouldInvoke()) return;
        if (changedNodes.has('ynab-u modal-popup modal-budget-activity ember-view modal-overlay active')) {
          this.invoke();
        }
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;
        this.invoke();
      }
    }]);

    return CategoryActivityCopy;
  }(_feature.Feature);

  /***/
},
/* 49 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CategoryActivityPopupWidth = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var CategoryActivityPopupWidth = exports.CategoryActivityPopupWidth = function (_Feature) {
    _inherits(CategoryActivityPopupWidth, _Feature);

    function CategoryActivityPopupWidth() {
      _classCallCheck(this, CategoryActivityPopupWidth);

      return _possibleConstructorReturn(this, (CategoryActivityPopupWidth.__proto__ || Object.getPrototypeOf(CategoryActivityPopupWidth)).apply(this, arguments));
    }

    _createClass(CategoryActivityPopupWidth, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1') {
          return __webpack_require__(50);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(52);
        }
      }
    }]);

    return CategoryActivityPopupWidth;
  }(_feature.Feature);

  /***/
},
/* 50 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(51);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 51 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".modal-budget-activity .modal {\n\twidth: 48em !important;\n}\n\n/* There are 5 columns all 20% width by default */\n/* Date column */\n.modal-budget-activity ul.budget-activity li:nth-child(2) {\n\twidth: 15%;\n}\n/* Memo column */\n.modal-budget-activity ul.budget-activity li:nth-child(4) {\n\twidth: 30%;\n}\n/* Amount column */\n.modal-budget-activity ul.budget-activity li:nth-child(5) {\n\twidth: 15%;\n}\n", ""]);

  // exports


  /***/
},
/* 52 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(53);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 53 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".modal-budget-activity .modal {\n\twidth: 64em !important;\n}\n\n/* There are 5 columns all 20% width by default */\n/* Date column */\n.modal-budget-activity ul.budget-activity li:nth-child(2) {\n\twidth: 10%;\n}\n/* Memo column */\n.modal-budget-activity ul.budget-activity li:nth-child(4) {\n\twidth: 40%;\n}\n/* Amount column */\n.modal-budget-activity ul.budget-activity li:nth-child(5) {\n\twidth: 10%;\n}", ""]);

  // exports


  /***/
},
/* 54 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.DaysOfBuffering = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var _outflowTransactionsFilter = __webpack_require__(55);

  var _outflowTransactionsFilter2 = _interopRequireDefault(_outflowTransactionsFilter);

  var _generateReport = __webpack_require__(57);

  var _generateReport2 = _interopRequireDefault(_generateReport);

  var _render2 = __webpack_require__(58);

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var DaysOfBuffering = exports.DaysOfBuffering = function (_Feature) {
    _inherits(DaysOfBuffering, _Feature);

    _createClass(DaysOfBuffering, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(59);
      }
    }]);

    function DaysOfBuffering() {
      _classCallCheck(this, DaysOfBuffering);

      var _this = _possibleConstructorReturn(this, (DaysOfBuffering.__proto__ || Object.getPrototypeOf(DaysOfBuffering)).call(this));

      _this.historyLookup = parseInt(ynabToolKit.options.DaysOfBufferingHistoryLookup);
      _this.transactionFilter = (0, _outflowTransactionsFilter2.default)(_this.historyLookup);
      _this.lastRenderTime = 0;
      _this.observe = _this.invoke;
      return _this;
    }

    _createClass(DaysOfBuffering, [{
      key: 'invoke',
      value: function invoke() {
        if (!(0, _render2.shouldRender)(this.lastRenderTime)) return;

        var transactions = this.entityManager.getAllTransactions().filter(this.transactionFilter);
        var report = (0, _generateReport2.default)(transactions, this.accountBalance);

        this.render(report);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return true;
      }
    }, {
      key: 'render',
      value: function render(report) {
        (0, _render2.render)(report);
        this.lastRenderTime = Date.now();
      }
    }, {
      key: 'entityManager',
      get: function get() {
        return (0, _toolkit.getEntityManager)();
      }
    }, {
      key: 'accountBalance',
      get: function get() {
        return ynab.YNABSharedLib.getBudgetViewModel_SidebarViewModel()._result.getOnBudgetAccountsBalance();
      }
    }]);

    return DaysOfBuffering;
  }(_feature.Feature);

  /***/
},
/* 55 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = filter;

  var _transaction = __webpack_require__(56);

  var isValidPayee = function isValidPayee(payee) {
    if (payee === null) {
      return true;
    }

    return payee.internalName !== 'StartingBalancePayee';
  };

  var isValidDate = function isValidDate(transactionTime, currentTime, historyLookupMonths) {
    if (historyLookupMonths !== 0) {
      return (currentTime - transactionTime) / 3600 / 24 / 1000 / (365 / 12) < historyLookupMonths;
    }
    return true;
  };

  function filter(historyLookupMonths) {
    var dateNow = Date.now();

    return function (transaction) {
      return !transaction.isTombstone && transaction.transferAccountId === null && transaction.amount < 0 && isValidPayee(transaction.getPayee()) && transaction.getAccount().onBudget && !(0, _transaction.isTransfer)(transaction) && isValidDate(transaction.getDate().getUTCTime(), dateNow, historyLookupMonths);
    };
  }

  /***/
},
/* 56 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.isTransfer = isTransfer;
  function isTransfer(transaction) {
    var masterCategoryId = transaction.get('masterCategoryId');
    var subCategoryId = transaction.get('subCategoryId');

    return masterCategoryId === null || subCategoryId === null;
  }

  /***/
},
/* 57 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = reportGenerator;

  function _toConsumableArray(arr) {
    if (Array.isArray(arr)) {
      for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
        arr2[i] = arr[i];
      }return arr2;
    } else {
      return Array.from(arr);
    }
  }

  function reportGenerator(transactions, totalBudget) {
    var transactionDates = transactions.map(function (t) {
      return t.getDate().getUTCTime();
    });
    var firstTransactionDate = Math.min.apply(Math, _toConsumableArray(transactionDates));
    var lastTransactionDate = Math.max.apply(Math, _toConsumableArray(transactionDates));
    var totalDays = (lastTransactionDate - firstTransactionDate) / 3600 / 24 / 1000;
    var totalOutflow = transactions.map(function (t) {
      return -t.amount;
    }).reduce(function (outflow, amount) {
      return outflow + amount;
    });
    var avgDailyOutflow = totalOutflow / totalDays;
    var avgDailyTransactions = transactions.length / totalDays;

    var daysOfBuffering = Math.floor(totalBudget / avgDailyOutflow);
    if (daysOfBuffering < 10) {
      daysOfBuffering = (totalBudget / avgDailyOutflow).toFixed(1);
    }

    if (totalDays < 15) {
      return { ableToGenerate: false };
    }

    return {
      daysOfBuffering: daysOfBuffering,
      totalOutflow: totalOutflow,
      totalDays: totalDays,
      avgDailyOutflow: avgDailyOutflow,
      avgDailyTransactions: avgDailyTransactions,
      ableToGenerate: true
    };
  }

  /***/
},
/* 58 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.shouldRender = exports.render = undefined;

  var _toolkit = __webpack_require__(2);

  var format = function format() {
    var _ynab$YNABSharedLib$c;

    return (_ynab$YNABSharedLib$c = ynab.YNABSharedLib.currencyFormatter).format.apply(_ynab$YNABSharedLib$c, arguments);
  };

  var getDobEl = function getDobEl() {
    return document.getElementsByClassName('days-of-buffering')[0];
  };

  var createDobEl = function createDobEl() {
    var elementForDoB = document.getElementsByClassName('budget-header-days')[0].cloneNode(true);

    elementForDoB.className = elementForDoB.className + ' days-of-buffering';
    elementForDoB.children[1].textContent = (0, _toolkit.i10n)('budget.ageOfMoneyDays.DoB', 'Days of Buffering');
    elementForDoB.children[1].title = "Don't like AoM? Try this out instead!";

    document.getElementsByClassName('budget-header-flexbox')[0].appendChild(elementForDoB);

    return elementForDoB;
  };

  var render = function render(_ref) {
    var daysOfBuffering = _ref.daysOfBuffering,
        totalOutflow = _ref.totalOutflow,
        totalDays = _ref.totalDays,
        avgDailyOutflow = _ref.avgDailyOutflow,
        avgDailyTransactions = _ref.avgDailyTransactions,
        ableToGenerate = _ref.ableToGenerate;

    var dobEl = getDobEl() || createDobEl();

    if (ableToGenerate) {
      var dayText = daysOfBuffering === 1.0 ? (0, _toolkit.i10n)('budget.ageOfMoneyDays.one', 'day') : (0, _toolkit.i10n)('budget.ageOfMoneyDays.other', 'days');

      dobEl.children[0].textContent = daysOfBuffering + ' ' + dayText;
      dobEl.children[0].title = 'Total outflow: ' + format(totalOutflow) + '\nTotal days of budgeting: ' + totalDays + '\nAverage daily outflow: ~' + format(avgDailyOutflow) + '\nAverage daily transactions: ' + avgDailyTransactions.toFixed(1);
    } else {
      dobEl.children[0].textContent = '???';
      dobEl.children[0].title = 'Your budget history is less than 15 days. Go on with YNAB a while.';
    }
  };

  var shouldRender = function shouldRender(lastRenderTime) {
    var debounce = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1000;

    var timeHasCome = Date.now() - lastRenderTime >= debounce;
    var headerVisible = document.getElementsByClassName('budget-header').length > 0;

    return timeHasCome && headerVisible;
  };

  exports.render = render;
  exports.shouldRender = shouldRender;

  /***/
},
/* 59 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(60);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 60 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-header-days.days-of-buffering {\n  display: block;\n  border-left: 1px solid #0e414c;\n}\n\n.days-of-buffering .budget-header-days-age {\n  white-space: nowrap;\n  color: #23b2ce;\n}\n", ""]);

  // exports


  /***/
},
/* 61 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.DisplayTargetGoalAmount = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var DisplayTargetGoalAmount = exports.DisplayTargetGoalAmount = function (_Feature) {
    _inherits(DisplayTargetGoalAmount, _Feature);

    function DisplayTargetGoalAmount() {
      _classCallCheck(this, DisplayTargetGoalAmount);

      return _possibleConstructorReturn(this, (DisplayTargetGoalAmount.__proto__ || Object.getPrototypeOf(DisplayTargetGoalAmount)).apply(this, arguments));
    }

    _createClass(DisplayTargetGoalAmount, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1 && this.settings.enabled !== '0';
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        var _this2 = this;

        $('.budget-table-header .budget-table-cell-name').css('position', 'relative');
        $('.budget-table-row.is-sub-category li.budget-table-cell-name').css('position', 'relative');

        $('.budget-table-header .budget-table-cell-name').append($('<div>', { class: 'budget-table-cell-goal' }).css({ position: 'absolute', right: 0, top: '6px' }).append('GOAL'));

        $('.budget-table-row.is-sub-category li.budget-table-cell-name').append($('<div>', { class: 'budget-table-cell-goal currency' }).css({
          background: '-webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 10%,rgba(255,255,255,1) 100%)', position: 'absolute', 'font-size': '80%', 'padding-left': '.75em', 'padding-right': '1px', 'line-height': '2.55em'
        }));

        $('.budget-table-row.is-sub-category').each(function (index, element) {
          var emberId = element.id;
          var viewData = toolkitHelper.getEmberView(emberId).data;
          var subCategory = viewData.subCategory;
          var monthlySubCategoryBudget = viewData.monthlySubCategoryBudget;
          var monthlySubCategoryBudgetCalculation = viewData.monthlySubCategoryBudgetCalculation;

          var goalType = subCategory.get('goalType');
          var monthlyFunding = subCategory.get('monthlyFunding');
          var targetBalance = subCategory.get('targetBalance');
          var targetBalanceDate = monthlySubCategoryBudgetCalculation.get('goalTarget');
          var budgetedAmount = monthlySubCategoryBudget.get('budgeted');
          if (goalType === 'MF') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(toolkitHelper.formatCurrency(monthlyFunding));
            if (budgetedAmount > monthlyFunding && _this2.settings.enabled === '1') {
              $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
            } else if (budgetedAmount >= monthlyFunding) {
              $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
            }
          } else if (goalType === 'TB') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(toolkitHelper.formatCurrency(targetBalance));
            if (budgetedAmount > targetBalance && _this2.settings.enabled === '1') {
              $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
            } else if (budgetedAmount >= targetBalance) {
              $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
            }
          } else if (goalType === 'TBD') {
            $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').text(toolkitHelper.formatCurrency(targetBalanceDate));
            if (budgetedAmount > targetBalanceDate && _this2.settings.enabled === '1') {
              $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#ff4545' });
            } else if (budgetedAmount >= targetBalanceDate) {
              $('#' + emberId + '.budget-table-row.is-sub-category div.budget-table-cell-goal').css({ color: '#00b300' });
            }
          }
        });
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!this.shouldInvoke()) return;
        if (changedNodes.has('budget-table-cell-budgeted')) {
          $('.budget-table-cell-goal').remove();
          this.invoke();
        }
        if (changedNodes.has('ynab-checkbox-button is-checked') || !changedNodes.has('ynab-checkbox-button is-checked')) {
          $('.budget-table-row.is-sub-category li.budget-table-cell-name .budget-table-cell-goal').css({
            background: '-webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 10%,rgba(255,255,255,1) 100%)' });
          $('.budget-table-row.is-checked li.budget-table-cell-name .budget-table-cell-goal').css({ background: '#005a6e' });
        }
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;
        this.invoke();
      }
    }]);

    return DisplayTargetGoalAmount;
  }(_feature.Feature);

  /***/
},
/* 62 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.EnableRetroCalculator = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var EnableRetroCalculator = exports.EnableRetroCalculator = function (_Feature) {
    _inherits(EnableRetroCalculator, _Feature);

    function EnableRetroCalculator() {
      _classCallCheck(this, EnableRetroCalculator);

      return _possibleConstructorReturn(this, (EnableRetroCalculator.__proto__ || Object.getPrototypeOf(EnableRetroCalculator)).apply(this, arguments));
    }

    _createClass(EnableRetroCalculator, [{
      key: 'onRouteChanged',
      value: function onRouteChanged(route) {
        // Remove our handler no matter what, because if they move between
        // months, we'll end up attaching multiple, which would be bad.
        // Let's always remove and then reattach if needed.
        var selector = 'li.budget-table-cell-budgeted div.currency-input, ' + 'div.ynab-grid-cell-outflow div.currency-input, ' + 'div.ynab-grid-cell-inflow div.currency-input';

        $(document).off('keypress', selector, this.handleKeypress);

        if (route === 'budget.select') {
          $(document).on('keypress', selector, this.handleKeypress);
        }
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        // If we're loading up on the budget page, then we should trigger
        // our listener on startup. Let's pretend we switched routes
        // so that the normal handling happens.
        return (0, _toolkit.getCurrentRouteName)() === 'budget.select';
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        this.onRouteChanged((0, _toolkit.getCurrentRouteName)());
      }
    }, {
      key: 'handleKeypress',
      value: function handleKeypress(e) {
        e = e || window.event;
        var charCode = e.which || e.keyCode;
        var charTyped = String.fromCharCode(charCode);

        if (charTyped === '+' || charTyped === '-' || charTyped === '*' || charTyped === '/') {
          var input = $(this).find('input');
          var length = input.val().length;

          // This moves the caret to the end of the input.
          input[0].focus();
          input[0].setSelectionRange(length, length);
        }

        // Make sure we allow the event to bubble up so we don't mess with anything
        // that YNAB is doing.
      }
    }]);

    return EnableRetroCalculator;
  }(_feature.Feature);

  /***/
},
/* 63 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.GoalWarningColor = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var GoalWarningColor = exports.GoalWarningColor = function (_Feature) {
    _inherits(GoalWarningColor, _Feature);

    function GoalWarningColor() {
      _classCallCheck(this, GoalWarningColor);

      return _possibleConstructorReturn(this, (GoalWarningColor.__proto__ || Object.getPrototypeOf(GoalWarningColor)).apply(this, arguments));
    }

    _createClass(GoalWarningColor, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(64);
      }
    }]);

    return GoalWarningColor;
  }(_feature.Feature);

  /***/
},
/* 64 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(65);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 65 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "/* row */\n.budget-table-row.toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious,\n.budget-table-row.toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious {\n\tbackground-color: #009cc2;\n}\n.budget-table-row.toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious:hover,\n.budget-table-row.toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) .budget-table-cell-available .cautious:hover {\n\tbackground-color: #1f8ca7;\n}\n\n/* inspector */\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) dt.cautious,\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) dt.cautious {\n\tcolor: #009cc2;\n}\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablepositive:not(.toolkit-row-upcoming) dd .cautious,\n.budget-inspector-category-overview .toolkit-row-goal.toolkit-row-availablezero:not(.toolkit-row-upcoming) dd .cautious {\n\tbackground: #009cc2;\n}\n\n/* goal */\n.goal-warning .inner-circle {\n\tstroke: #43aecb;\t\n}\n.goal-warning .outer-circle {\n\tfill: #1f8ca7;\n}\n", ""]);

  // exports


  /***/
},
/* 66 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CurrentMonthIndicator = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var CurrentMonthIndicator = exports.CurrentMonthIndicator = function (_Feature) {
    _inherits(CurrentMonthIndicator, _Feature);

    function CurrentMonthIndicator() {
      _classCallCheck(this, CurrentMonthIndicator);

      return _possibleConstructorReturn(this, (CurrentMonthIndicator.__proto__ || Object.getPrototypeOf(CurrentMonthIndicator)).apply(this, arguments));
    }

    _createClass(CurrentMonthIndicator, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(67);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        if (this.inCurrentMonth()) {
          $('.budget-header .budget-header-calendar').addClass('toolkit-highlight-current-month');
        } else {
          $('.budget-header .budget-header-calendar').removeClass('toolkit-highlight-current-month');
        }
      }
    }, {
      key: 'inCurrentMonth',
      value: function inCurrentMonth() {
        var today = new Date();
        var selectedMonth = ynabToolKit.shared.parseSelectedMonth();
        if (selectedMonth === null) return false;
        return selectedMonth.getMonth() === today.getMonth() && selectedMonth.getYear() === today.getYear();
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!this.shouldInvoke()) return;

        if (changedNodes.has('budget-header-item budget-header-calendar') || changedNodes.has('budget-header-totals-cell-value user-data')) {
          this.invoke();
        }
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;
        this.invoke();
      }
    }]);

    return CurrentMonthIndicator;
  }(_feature.Feature);

  /***/
},
/* 67 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(68);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 68 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "/* add transitions */\n.budget-header .budget-header-item {\n\tpadding: .7em .6em .6em;\n\t-moz-transition: background-color .3s linear;\n\t-webkit-transition: background-color .3s linear;\n\t-o-transition: background-color .3s linear;\n\ttransition: background-color .3s linear;\n}\n.budget-header .budget-header-item .budget-header-calendar-prev,\n.budget-header .budget-header-item .budget-header-calendar-next,\n.budget-header .budget-header-item .flaticon,\n.budget-header .budget-header-item .budget-header-calendar-note {\n\t-moz-transition: color .2s linear;\n\t-webkit-transition: color .2s linear;\n\t-o-transition: color .2s linear;\n\ttransition: color .2s linear;\n}\n\n/* current month styles */\n.toolkit-highlight-current-month {\n\tbackground: #00596f !important;\n}\n.budget-header .toolkit-highlight-current-month .budget-header-calendar-prev, \n.budget-header .toolkit-highlight-current-month .budget-header-calendar-next,\n.budget-header .toolkit-highlight-current-month .flaticon {\n\tcolor: #bee6ef;\n}\n.budget-header .toolkit-highlight-current-month:hover .flaticon:not(.disabled) {\n\tcolor: #fff;\n}\n.budget-header .toolkit-highlight-current-month .budget-header-calendar-note {\n\tcolor: rgba(255,255,255,0.4);\n}", ""]);

  // exports


  /***/
},
/* 69 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.MonthlyNotesPopupWidth = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var MonthlyNotesPopupWidth = exports.MonthlyNotesPopupWidth = function (_Feature) {
    _inherits(MonthlyNotesPopupWidth, _Feature);

    function MonthlyNotesPopupWidth() {
      _classCallCheck(this, MonthlyNotesPopupWidth);

      return _possibleConstructorReturn(this, (MonthlyNotesPopupWidth.__proto__ || Object.getPrototypeOf(MonthlyNotesPopupWidth)).apply(this, arguments));
    }

    _createClass(MonthlyNotesPopupWidth, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1') {
          return __webpack_require__(70);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(72);
        }
      }
    }]);

    return MonthlyNotesPopupWidth;
  }(_feature.Feature);

  /***/
},
/* 70 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(71);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 71 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "body .modal-budget-note .modal {\n\twidth: 24em !important;\n}", ""]);

  // exports


  /***/
},
/* 72 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(73);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 73 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "body .modal-budget-note .modal {\n\twidth: 34em !important;\n}", ""]);

  // exports


  /***/
},
/* 74 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.QuickBudgetWarning = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var QuickBudgetWarning = exports.QuickBudgetWarning = function (_Feature) {
    _inherits(QuickBudgetWarning, _Feature);

    function QuickBudgetWarning() {
      _classCallCheck(this, QuickBudgetWarning);

      return _possibleConstructorReturn(this, (QuickBudgetWarning.__proto__ || Object.getPrototypeOf(QuickBudgetWarning)).apply(this, arguments));
    }

    _createClass(QuickBudgetWarning, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') > -1;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        // target only buttons so other elements with same class can be added without forcing
        // confirmation, which can break the quick budget functionality for quick budget
        // items added by the Toolkit
        $('button.budget-inspector-button').off('click', this.confirmClick);
        $('button.budget-inspector-button').on('click', this.confirmClick);
      }
    }, {
      key: 'confirmClick',
      value: function confirmClick(event) {
        if (!confirm('Are you sure you want to do this?')) {
          // eslint-disable-line no-alert
          event.preventDefault();
          event.stopPropagation();
        }
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (changedNodes.has('navlink-budget active') || changedNodes.has('budget-inspector') || changedNodes.has('inspector-quick-budget')) {
          this.invoke();
        }
      }
    }]);

    return QuickBudgetWarning;
  }(_feature.Feature);

  /***/
},
/* 75 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.RemovePositiveHighlight = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var RemovePositiveHighlight = exports.RemovePositiveHighlight = function (_Feature) {
    _inherits(RemovePositiveHighlight, _Feature);

    function RemovePositiveHighlight() {
      _classCallCheck(this, RemovePositiveHighlight);

      return _possibleConstructorReturn(this, (RemovePositiveHighlight.__proto__ || Object.getPrototypeOf(RemovePositiveHighlight)).apply(this, arguments));
    }

    _createClass(RemovePositiveHighlight, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(76);
      }
    }]);

    return RemovePositiveHighlight;
  }(_feature.Feature);

  /***/
},
/* 76 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(77);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 77 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-table-row.is-sub-category > .budget-table-cell-available .positive,\n.budget-table-row.is-sub-category.is-checked.goal-progress > .budget-table-cell-available .positive {\n\tbackground-color: transparent;\n\tcolor: #16a336;\n\tfont-weight: bold;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive:hover,\n.inspector-overview-available .positive {\n\tbackground-color: transparent;\n\tcolor: #138b2e;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\tbackground-color: transparent;\n\tcolor: #cfd5d8;\n\tfont-weight: normal;\n}\n\n.budget-table-row.is-sub-category.is-checked.goal-progress > .budget-table-cell-available .positive\n{\n\tcolor: #16a336;\n\tfont-weight: bold;\n}\n\n.budget-table-row.is-sub-category.is-checked > .budget-table-cell-available .positive,\n.budget-table-row.is-sub-category.is-checked > .budget-table-cell-available .zero {\n\tcolor: #fff;\n}\n\n\n", ""]);

  // exports


  /***/
},
/* 78 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ResizeInspector = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var HIDEIMAGE = 'toolkit-modal-item-hide-image';
  var BUTTONDISABLED = 'button-disabled';
  var IMAGECLASSES = 'ember-view toolkit-menu-item toolkit-modal-item-hide-image flaticon stroke checkmark-1';

  var ResizeInspector = exports.ResizeInspector = function (_Feature) {
    _inherits(ResizeInspector, _Feature);

    function ResizeInspector() {
      _classCallCheck(this, ResizeInspector);

      return _possibleConstructorReturn(this, (ResizeInspector.__proto__ || Object.getPrototypeOf(ResizeInspector)).apply(this, arguments));
    }

    _createClass(ResizeInspector, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(79);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1 && this.settings.enabled;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        var width = toolkitHelper.getToolkitStorageKey('inspector-width', 'number');
        if (typeof width === 'undefined' || width === null) {
          width = 0;
        }

        this.setProperties(width);
        this.addResizeButton();
      }
    }, {
      key: 'addResizeButton',
      value: function addResizeButton() {
        var _this3 = this;

        if (!$('#toolkitResizeInspector').length) {
          var buttonText = ynabToolKit.l10nData && ynabToolKit.l10nData['toolkit.InspectorWidth'] || 'Inspector Width';
          $('<button>', { id: 'toolkitResizeInspector', class: 'ember-view button', style: 'float: right' }).append($('<i>', { class: 'ember-view flaticon stroke gear-1' })).append(' ' + buttonText).click(function () {
            _this3.showResizeModal();
          }).insertAfter('.undo-redo-container');
        }
      }
    }, {
      key: 'showResizeModal',
      value: function showResizeModal() {
        var _this = this;
        var btnLeft = $('.budget-toolbar').outerWidth() + $('#toolkitResizeInspector').outerWidth() + 29;
        var btnTop = $('.budget-toolbar').outerHeight() + $('.budget-header-flexbox').outerHeight() + 8;
        var $modal = $('<div>', { id: 'toolkitInspectorODiv', class: 'ember-view' }).append($('<div>', { id: 'toolkitInspectorModal', class: 'ynab-u modal-popup modal-resize-inspector ember-view modal-overlay active' }).append($('<div>', { id: 'toolkitInspectorIDiv', class: 'modal', style: 'left:' + btnLeft + 'px; top: ' + btnTop + 'px;' }).append($('<ul>', { class: 'modal-list' }).append($('<li>').append($('<button>', { 'data-inspector-size': '0', class: 'button-list' }).click(function () {
          _this.setProperties($(this).data('inspector-size'));
        }).append($('<i>', { class: IMAGECLASSES })).append('Default '))).append($('<li>').append($('<button>', { 'data-inspector-size': '1', class: 'button-list' }).click(function () {
          _this.setProperties($(this).data('inspector-size'));
        }).append($('<i>', { class: IMAGECLASSES })).append('25% '))).append($('<li>').append($('<button>', { 'data-inspector-size': '2', class: 'button-list' }).click(function () {
          _this.setProperties($(this).data('inspector-size'));
        }).append($('<i>', { class: IMAGECLASSES })).append('20% '))).append($('<li>').append($('<button>', { 'data-inspector-size': '3', class: 'button-list' }).click(function () {
          _this.setProperties($(this).data('inspector-size'));
        }).append($('<i>', { class: IMAGECLASSES })).append('15% ')))).append($('<div>', { class: 'modal-arrow', style: 'position:absolute;width: 0;height: 0;bottom: 100%;left: 37px;border: solid transparent;border-color: transparent;border-width: 15px;border-bottom-color: #fff' }))));

        // Handle dismissal of modal via the ESC key
        $(document).one('keydown', function (e) {
          if (e.keyCode === 27) {
            // ESC key?
            $(document).off('click.toolkitResizeInspector');
            $('#toolkitInspectorODiv').remove();
          }
        });

        // Handle mouse clicks outside the drop-down modal. Namespace the
        // click event so we can remove our specific instance.
        $(document).on('click.toolkitResizeInspector', function (e) {
          if (e.target.id === 'toolkitInspectorModal') {
            $(document).off('click.toolkitResizeInspector');
            $('#toolkitInspectorODiv').remove();
          }
        });

        var width = toolkitHelper.getToolkitStorageKey('inspector-width', 'number');
        var btn = $modal.find('button[data-inspector-size="' + width + '"]');
        btn.prop('disabled', true);
        btn.addClass(BUTTONDISABLED);
        var img = $modal.find('button[data-inspector-size="' + width + '"] > i');
        img.removeClass(HIDEIMAGE);

        // Don't append until all the menu items have been set.
        $('.layout').append($modal);
      }
    }, {
      key: 'setProperties',
      value: function setProperties(width) {
        if ($('.budget-content').length) {
          var contentWidth = '67%';
          var inspectorWidth = '33%';

          if (width === 1) {
            contentWidth = '75%';
            inspectorWidth = '25%';
          } else if (width === 2) {
            contentWidth = '80%';
            inspectorWidth = '20%';
          } else if (width === 3) {
            contentWidth = '85%';
            inspectorWidth = '15%';
          }

          $('.budget-content')[0].style.setProperty('--toolkit-content-width', contentWidth);
          $('.budget-inspector')[0].style.setProperty('--toolkit-inspector-width', inspectorWidth);

          // Save the users current selection for future page loads.
          toolkitHelper.setToolkitStorageKey('inspector-width', width);

          // Remove our click event handler and the modal div.
          $(document).off('click.toolkitInspector');
          $('#toolkitInspectorODiv').remove();
        }
      }
    }, {
      key: 'onBudgetChanged',
      value: function onBudgetChanged() {
        if (!this.shouldInvoke()) return;
        this.invoke();
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;
        this.invoke();
      }
    }]);

    return ResizeInspector;
  }(_feature.Feature);

  /***/
},
/* 79 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(80);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 80 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-content {\n  width: var(--toolkit-content-width, 75%) !important; /* default to our widest width */\n}\n\n.budget-inspector {\n  min-width: var(--toolkit-inspector-minwidth, inherit) !important;\n  width: var(--toolkit-inspector-width, 25%) !important; /* default to our widest width */\n}\n\n.toolkit-modal-item-hide-image {\n  visibility: hidden;\n}\n\n.modal-resize-inspector {\n  background-color: transparent;\n}\n\n.modal-resize-inspector .modal {\n  padding: .3em 0;\n  width: 7em;\n  font-size: .9em;\n}\n", ""]);

  // exports


  /***/
},
/* 81 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.RowsHeight = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var RowsHeight = exports.RowsHeight = function (_Feature) {
    _inherits(RowsHeight, _Feature);

    function RowsHeight() {
      _classCallCheck(this, RowsHeight);

      return _possibleConstructorReturn(this, (RowsHeight.__proto__ || Object.getPrototypeOf(RowsHeight)).apply(this, arguments));
    }

    _createClass(RowsHeight, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1') {
          return __webpack_require__(82);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(84);
        } else if (this.settings.enabled === '3') {
          return __webpack_require__(86);
        }
      }
    }]);

    return RowsHeight;
  }(_feature.Feature);

  /***/
},
/* 82 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(83);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 83 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-content ul.budget-table-header {\n  height: 1.6em !important;\n}\n\n.budget-table {\n  top: 1.4em !important;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n  height: 2em;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-add-category .flaticon {\n  top: 0.25em;\n}\n\n.budget-table-row.is-sub-category {\n  height: 1.8em !important;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-name {\n  padding-top: 0;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive, .budget-table-row.is-sub-category > .budget-table-cell-available .negative, .budget-table-row.is-sub-category > .budget-table-cell-available .cautious, .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n  top: 0 !important;\n  padding: 0.1em 0.3em;\n}\n\n.budget-table-row.is-sub-category .budget-table-cell-activity {\n  top: 0 !important;\n}\n\n.budget-table-cell-budgeted .currency-input span {\n  height: 1.8em;\n}\n\n.toolkit-goalindicator {\n  line-height: 1.8em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 84 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(85);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 85 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-content ul, .budget-table-row.is-dragging {\n  height: 1.6em;\n}\n\n.budget-table-row.is-master-category {\n  margin-top: 0px;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-name .budget-table-cell-name-row-label-item {\n  padding-top: 0.1em !important;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-add-category .flaticon {\n  top: 0.2em;\n}\n\n.budget-table-row.is-sub-category {\n  height: 1.42em !important;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-name {\n  padding-top: 0;\n  font-size: 1.05em;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive, .budget-table-row.is-sub-category > .budget-table-cell-available .negative, .budget-table-row.is-sub-category > .budget-table-cell-available .cautious, .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n  top: 0 !important;\n  padding: 0em 0.4em !important;\n  font-size: 1em !important;\n}\n\n.budget-table-row.is-sub-category .budget-table-cell-activity {\n  top: 0 !important;\n}\n\n.budget-table-cell-budgeted .currency-input span {\n  height: 1.45em;\n  padding: 0.05em;\n  border-width: 1px !important;\n}\n\n.budget-table-cell-budgeted .currency-input input {\n  height: 1.45em !important;\n}\n\n.toolkit-goalindicator {\n  line-height: 1.3em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 86 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(87);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 87 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-content ul, .budget-table-row.is-dragging {\n  height: 1.6em;\n}\n\n.budget-table-row.is-master-category {\n  margin-top: 0px;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-name .budget-table-cell-name-row-label-item {\n  padding-top: 0.1em !important;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-add-category .flaticon {\n  top: 0.2em;\n}\n\n.budget-table-row.is-sub-category {\n  height: 1.6em !important;\n  font-size: 0.78em;\n}\n\n.budget-table-row.is-master-category .budget-table-cell-name {\n  padding-top: 0;\n  font-size: 1.05em;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .positive, .budget-table-row.is-sub-category > .budget-table-cell-available .negative, .budget-table-row.is-sub-category > .budget-table-cell-available .cautious, .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n  top: 0 !important;\n  padding: 0em 0.4em;\n  font-size: 1em !important;\n}\n\n.budget-table-row.is-sub-category .budget-table-cell-activity {\n  top: 0 !important;\n}\n\n.budget-table-cell-budgeted .currency-input span {\n  height: 1.45em;\n  padding: 0.05em;\n  border-width: 1px !important;\n}\n\n.budget-table-cell-budgeted .currency-input input {\n  height: 1.45em !important;\n}\n\n.toolkit-goalindicator {\n  line-height: 1.8em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 88 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SeamlessBudgetHeader = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var SeamlessBudgetHeader = exports.SeamlessBudgetHeader = function (_Feature) {
    _inherits(SeamlessBudgetHeader, _Feature);

    function SeamlessBudgetHeader() {
      _classCallCheck(this, SeamlessBudgetHeader);

      return _possibleConstructorReturn(this, (SeamlessBudgetHeader.__proto__ || Object.getPrototypeOf(SeamlessBudgetHeader)).apply(this, arguments));
    }

    _createClass(SeamlessBudgetHeader, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(89);
      }
    }]);

    return SeamlessBudgetHeader;
  }(_feature.Feature);

  /***/
},
/* 89 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(90);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 90 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-header .budget-header-item {\n\tborder-left: 0px;\n}\n", ""]);

  // exports


  /***/
},
/* 91 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.StealingFromFuture = undefined;

  var _slicedToArray = function () {
    function sliceIterator(arr, i) {
      var _arr = [];var _n = true;var _d = false;var _e = undefined;try {
        for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
          _arr.push(_s.value);if (i && _arr.length === i) break;
        }
      } catch (err) {
        _d = true;_e = err;
      } finally {
        try {
          if (!_n && _i["return"]) _i["return"]();
        } finally {
          if (_d) throw _e;
        }
      }return _arr;
    }return function (arr, i) {
      if (Array.isArray(arr)) {
        return arr;
      } else if (Symbol.iterator in Object(arr)) {
        return sliceIterator(arr, i);
      } else {
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
      }
    };
  }();

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  // TODO: move income-from-last-month to the new framework and just export this
  // variable from that feature
  var INCOME_FROM_LAST_MONTH_CLASSNAME = 'income-from-last-month';

  var StealingFromFuture = exports.StealingFromFuture = function (_Feature) {
    _inherits(StealingFromFuture, _Feature);

    function StealingFromFuture() {
      _classCallCheck(this, StealingFromFuture);

      return _possibleConstructorReturn(this, (StealingFromFuture.__proto__ || Object.getPrototypeOf(StealingFromFuture)).apply(this, arguments));
    }

    _createClass(StealingFromFuture, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(92);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1;
      }
    }, {
      key: 'isMonthABeforeB',
      value: function isMonthABeforeB(a, b) {
        if (b === null) return true;

        var _a$split$map = a.split('-').map(function (val) {
          return parseInt(val);
        }),
            _a$split$map2 = _slicedToArray(_a$split$map, 2),
            yearA = _a$split$map2[0],
            monthA = _a$split$map2[1];

        var _b$split$map = b.split('-').map(function (val) {
          return parseInt(val);
        }),
            _b$split$map2 = _slicedToArray(_b$split$map, 2),
            yearB = _b$split$map2[0],
            monthB = _b$split$map2[1];

        if (yearA >= yearB && monthA >= monthB) {
          return false;
        }

        return true;
      }
    }, {
      key: 'onAvailableToBudgetChange',
      value: function onAvailableToBudgetChange(budgetViewModel) {
        var _this2 = this;

        var earliestEntityDate = null;
        var earliestNegativeMonth = null;
        var earliestNegativeMonthCalculation = null;
        budgetViewModel.get('allBudgetMonthsViewModel.monthlyBudgetCalculationsCollection').forEach(function (monthCalculation) {
          if (_this2.isMonthEntityIdFuture(monthCalculation.get('entityId'))) {
            var entityDate = monthCalculation.get('entityId').match(/mbc\/(.*)\/.*/)[1];
            var entityMonth = entityDate.split('-').map(function (val) {
              return parseInt(val);
            })[1];

            if (monthCalculation.get('availableToBudget') < 0 && _this2.isMonthABeforeB(entityDate, earliestEntityDate)) {
              earliestEntityDate = entityDate;
              earliestNegativeMonth = entityMonth;
              earliestNegativeMonthCalculation = monthCalculation;
            }
          }
        });

        // there's no easy class name on the thing we want to highlight so
        // we have to just select the specific row. if the user has the income
        // from last month feature on and it has already invoked, then the row
        // we want is number 4, else 3.
        var futureBudgetRow = 3;
        if (ynabToolKit.options.incomeFromLastMonth !== '0') {
          if ($('.budget-header-totals-details-values .' + INCOME_FROM_LAST_MONTH_CLASSNAME).length) {
            futureBudgetRow = 4;
          }
        }

        var value = $('.budget-header-totals-details-values .budget-header-totals-cell-value').eq(futureBudgetRow);
        var name = $('.budget-header-totals-details-names .budget-header-totals-cell-name').eq(futureBudgetRow);

        // no negative months! good job team!
        if (earliestNegativeMonth === null) {
          value.removeClass('ynabtk-stealing-from-next-month');
          name.removeClass('ynabtk-stealing-from-next-month');
          $('#ynabtk-stealing-amount', name).remove();
          return;
        }

        value.addClass('ynabtk-stealing-from-next-month');
        name.addClass('ynabtk-stealing-from-next-month');

        var availableToBudget = earliestNegativeMonthCalculation.getAvailableToBudget();
        $('#ynabtk-stealing-amount', name).remove();
        name.append('<span id="ynabtk-stealing-amount"> (' + '<strong>' + (ynab.formatCurrency(availableToBudget) + ' in ') + ('<a class="ynabtk-month-link">' + ynabToolKit.shared.monthsFull[earliestNegativeMonth - 1] + '</a>') + '</strong>' + ')</span>');

        $('.ynabtk-month-link', name).click(function (event) {
          event.preventDefault();
          var applicationController = toolkitHelper.controllerLookup('application');
          var budgetVersionId = applicationController.get('budgetVersionId');
          toolkitHelper.transitionTo('budget.select', budgetVersionId, earliestEntityDate.replace('-', ''));
        });
      }
    }, {
      key: 'isMonthEntityIdFuture',
      value: function isMonthEntityIdFuture(entityId) {
        var currentYear = parseInt(moment().format('YYYY'));
        var currentMonth = parseInt(moment().format('MM'));
        var entityDate = entityId.match(/mbc\/(.*)\/.*/)[1];

        var _entityDate$split$map = entityDate.split('-').map(function (val) {
          return parseInt(val);
        }),
            _entityDate$split$map2 = _slicedToArray(_entityDate$split$map, 2),
            entityYear = _entityDate$split$map2[0],
            entityMonth = _entityDate$split$map2[1];

        if (entityYear >= currentYear && entityMonth > currentMonth) {
          return true;
        }

        return false;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        var _this3 = this;

        var budgetController = ynabToolKit.shared.containerLookup('controller:budget');
        var budgetViewModel = budgetController.get('budgetViewModel');
        if (budgetViewModel) {
          budgetViewModel.get('allBudgetMonthsViewModel.monthlyBudgetCalculationsCollection').forEach(function (month) {
            month.addObserver('availableToBudget', _this3.onAvailableToBudgetChange.bind(_this3, budgetViewModel));
          });

          this.onAvailableToBudgetChange(budgetViewModel);
        }
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;
        this.invoke();
      }
    }]);

    return StealingFromFuture;
  }(_feature.Feature);

  /***/
},
/* 92 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(93);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 93 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynabtk-stealing-from-next-month {\n\tcolor: red;\n}\n\n.ynabtk-month-link {\n\tcursor: pointer;\n\ttext-decoration: underline;\n}\n", ""]);

  // exports


  /***/
},
/* 94 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.TargetBalanceWarning = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var TargetBalanceWarning = exports.TargetBalanceWarning = function (_Feature) {
    _inherits(TargetBalanceWarning, _Feature);

    function TargetBalanceWarning() {
      _classCallCheck(this, TargetBalanceWarning);

      return _possibleConstructorReturn(this, (TargetBalanceWarning.__proto__ || Object.getPrototypeOf(TargetBalanceWarning)).call(this));
    }

    _createClass(TargetBalanceWarning, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        $('.budget-table-row.is-sub-category').each(function (index, element) {
          var emberId = element.id;
          var viewData = toolkitHelper.getEmberView(emberId).data;
          var subCategory = viewData.subCategory;

          if (subCategory.get('goalType') === ynab.constants.SubCategoryGoalType.TargetBalance) {
            var available = viewData.get('available');
            var targetBalance = subCategory.get('targetBalance');
            var currencyElement = $('.budget-table-cell-available .user-data.currency', element);

            if (available < targetBalance && !currencyElement.hasClass('cautious')) {
              if (currencyElement.hasClass('positive')) {
                currencyElement.removeClass('positive');
              }

              currencyElement.addClass('cautious');
            }
          }
        });
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!this.shouldInvoke()) return;

        if (changedNodes.has('budget-table-cell-available-div user-data')) {
          this.invoke();
        }
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;
        this.invoke();
      }
    }]);

    return TargetBalanceWarning;
  }(_feature.Feature);

  /***/
},
/* 95 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ToBeBudgetedWarning = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ToBeBudgetedWarning = exports.ToBeBudgetedWarning = function (_Feature) {
    _inherits(ToBeBudgetedWarning, _Feature);

    function ToBeBudgetedWarning() {
      _classCallCheck(this, ToBeBudgetedWarning);

      return _possibleConstructorReturn(this, (ToBeBudgetedWarning.__proto__ || Object.getPrototypeOf(ToBeBudgetedWarning)).apply(this, arguments));
    }

    _createClass(ToBeBudgetedWarning, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(96);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        // check if TBB > zero, if so, change background color
        if ($('.budget-header-totals-amount-value .currency').hasClass('positive')) {
          $('.budget-header-totals-amount').addClass('toolkit-cautious');
          $('.budget-header-totals-amount-arrow').addClass('toolkit-cautious');
        } else {
          $('.budget-header-totals-amount').removeClass('toolkit-cautious');
          $('.budget-header-totals-amount-arrow').removeClass('toolkit-cautious');
        }
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!this.shouldInvoke()) return;

        if (changedNodes.has('budget-header-item budget-header-calendar') || changedNodes.has('budget-header-totals-cell-value user-data')) {
          this.invoke();
        }
      }
    }, {
      key: 'onRouteChanged',
      value: function onRouteChanged() {
        if (!this.shouldInvoke()) return;
        this.invoke();
      }
    }]);

    return ToBeBudgetedWarning;
  }(_feature.Feature);

  /***/
},
/* 96 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(97);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 97 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "body .budget-header-totals-amount.toolkit-cautious {\n\tbackground-color: #e59100;\n}\nbody .budget-header-totals-amount-arrow.toolkit-cautious .arrow {\n\tborder-left: 1em solid #e59100;\n}", ""]);

  // exports


  /***/
},
/* 98 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ToggleMasterCategories = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ToggleMasterCategories = exports.ToggleMasterCategories = function (_Feature) {
    _inherits(ToggleMasterCategories, _Feature);

    function ToggleMasterCategories() {
      var _ref;

      var _temp, _this, _ret;

      _classCallCheck(this, ToggleMasterCategories);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = ToggleMasterCategories.__proto__ || Object.getPrototypeOf(ToggleMasterCategories)).call.apply(_ref, [this].concat(args))), _this), _this.toggleMasterCategories = function (event) {
        var container = $('.undo-redo-container');
        var min = container.offset().left + container.outerWidth() - 2;
        var max = min + 28;

        if (event.pageX >= min && event.pageX <= max) {
          // if some sections are already hidden, expand all
          if ($('.is-master-category .budget-table-cell-name-static-width button.right').length) {
            $('.is-master-category .budget-table-cell-name-static-width button.right').click();
          } else {
            $('.is-master-category .budget-table-cell-name-static-width button.down').click();
          }
        }
      }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(ToggleMasterCategories, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(99);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        // since we are adding the listener to the entire document,
        // we should invoke on page load.
        return true;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        $(document).on('click.toolkit-toggle-master-cats', '.undo-redo-container', this.toggleMasterCategories);
      }
    }]);

    return ToggleMasterCategories;
  }(_feature.Feature);

  /***/
},
/* 99 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(100);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 100 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-toolbar > .undo-redo-container::after {\n  content: '\\E592';\n  font-family: 'Flaticons Stroke';\n  -webkit-font-smoothing: antialiased;\n  font-size: 1.125em;\n  color: #009cc2;\n  padding: .4em .5em;\n  position: absolute;\n  cursor: pointer;\n}\n", ""]);

  // exports


  /***/
},
/* 101 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.AccountsDisplayDensity = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var AccountsDisplayDensity = exports.AccountsDisplayDensity = function (_Feature) {
    _inherits(AccountsDisplayDensity, _Feature);

    function AccountsDisplayDensity() {
      _classCallCheck(this, AccountsDisplayDensity);

      return _possibleConstructorReturn(this, (AccountsDisplayDensity.__proto__ || Object.getPrototypeOf(AccountsDisplayDensity)).apply(this, arguments));
    }

    _createClass(AccountsDisplayDensity, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1') {
          return __webpack_require__(102);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(104);
        }
      }
    }]);

    return AccountsDisplayDensity;
  }(_feature.Feature);

  /***/
},
/* 102 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(103);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 103 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-account-row {\n     line-height: normal  !important;\n     padding: 0.025em 0 !important;\n\n}\n", ""]);

  // exports


  /***/
},
/* 104 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(105);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 105 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-account-row {\n     line-height: normal  !important;\n     padding: 0.01em 0 !important;\n     font-size: .85em !important;\n}\n", ""]);

  // exports


  /***/
},
/* 106 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.BetterScrollbars = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var BetterScrollbars = exports.BetterScrollbars = function (_Feature) {
    _inherits(BetterScrollbars, _Feature);

    function BetterScrollbars() {
      _classCallCheck(this, BetterScrollbars);

      return _possibleConstructorReturn(this, (BetterScrollbars.__proto__ || Object.getPrototypeOf(BetterScrollbars)).apply(this, arguments));
    }

    _createClass(BetterScrollbars, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1') {
          return __webpack_require__(107);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(109);
        } else if (this.settings.enabled === '3') {
          return __webpack_require__(111);
        }
      }
    }]);

    return BetterScrollbars;
  }(_feature.Feature);

  /***/
},
/* 107 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(108);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 108 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "::-webkit-scrollbar {\n   width: 6px;\n}\n\n::-webkit-scrollbar-thumb {\n   border-radius: 3px;\n   background: rgba(0,89,111,0.6);\n}\n", ""]);

  // exports


  /***/
},
/* 109 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(110);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 110 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "::-webkit-scrollbar {\n   width: 2px;\n}\n\n::-webkit-scrollbar-thumb {\n   border-radius: 1px;\n   background: rgba(0,89,111,0.6);\n}\n", ""]);

  // exports


  /***/
},
/* 111 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(112);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 112 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "::-webkit-scrollbar {\n   width: 0px;\n}\n", ""]);

  // exports


  /***/
},
/* 113 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.BudgetQuickSwitch = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var BudgetQuickSwitch = exports.BudgetQuickSwitch = function (_Feature) {
    _inherits(BudgetQuickSwitch, _Feature);

    function BudgetQuickSwitch() {
      _classCallCheck(this, BudgetQuickSwitch);

      return _possibleConstructorReturn(this, (BudgetQuickSwitch.__proto__ || Object.getPrototypeOf(BudgetQuickSwitch)).apply(this, arguments));
    }

    _createClass(BudgetQuickSwitch, [{
      key: 'populateBudgetList',
      value: function populateBudgetList() {
        var applicationController = (0, _toolkit.controllerLookup)('application');
        var currentBudgetId = applicationController.get('activeBudgetVersion').get('entityId');
        var $openBudgetListItem = $('.modal-select-budget').find('.modal-select-budget-open').parent();

        ynab.YNABSharedLib.getCatalogViewModel_UserViewModel().then(function (_ref) {
          var userBudgetDisplayItems = _ref.userBudgetDisplayItems;

          userBudgetDisplayItems.filter(function (budget) {
            return !budget.get('isTombstone');
          }).forEach(function (budget) {
            var budgetVersionId = budget.get('budgetVersionId');
            var budgetVersionName = budget.get('budgetVersionName');

            if (budgetVersionId === currentBudgetId) return;

            var budgetListItem = $('<li>').append($('<button>', { text: budgetVersionName }).prepend($('<i>', {
              class: 'flaticon stroke mail-1'
            }))).click(function () {
              var router = (0, _toolkit.getRouter)();
              router.send('openBudget', budgetVersionId, budgetVersionName);
            });

            $openBudgetListItem.after(budgetListItem);
          });
        });
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (changedNodes.has('ynab-u modal-popup modal-select-budget ember-view modal-overlay active')) {
          this.populateBudgetList();
        }
      }
    }]);

    return BudgetQuickSwitch;
  }(_feature.Feature);

  /***/
},
/* 114 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CollapseSideMenu = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var CollapseSideMenu = exports.CollapseSideMenu = function (_Feature) {
    _inherits(CollapseSideMenu, _Feature);

    function CollapseSideMenu() {
      var _ref;

      var _temp, _this2, _ret;

      _classCallCheck(this, CollapseSideMenu);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this2 = _possibleConstructorReturn(this, (_ref = CollapseSideMenu.__proto__ || Object.getPrototypeOf(CollapseSideMenu)).call.apply(_ref, [this].concat(args))), _this2), _this2.collapseBtn = '', _this2.originalButtons = {}, _this2.originalSizes = {
        sidebarWidth: 0,
        contentLeft: 0,
        headerLeft: 0,
        contentWidth: 0,
        inspectorWidth: 0
      }, _temp), _possibleConstructorReturn(_this2, _ret);
    }

    _createClass(CollapseSideMenu, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(115);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return toolkitHelper.getCurrentRouteName().indexOf('budget') !== -1;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        this.collapseBtn = $('<li>', { class: 'ember-view ynabtk-navlink-collapse' }).append($('<a>', { class: 'ynabtk-collapse-link' }).append($('<span>', { class: 'ember-view flaticon stroke left-circle-4' })).append(toolkitHelper.i10n('toolkit.collapse', 'Collapse')));

        this.setupBtns();
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (this.shouldInvoke()) {
          if (changedNodes.has('layout user-logged-in')) {
            if ($('.nav-main').length) {
              this.setupBtns();
            }
          }

          if (changedNodes.has('nav-main')) {
            var numNavLinks = $('.nav-main').children().length;
            var collapseIndex = $('.nav-main').children().index($('.ynabtk-navlink-collapse'));
            var numCollapsedLinks = $('.collapsed-buttons').children().length;

            if (numNavLinks > collapseIndex + 1 || numNavLinks > numCollapsedLinks) {
              $('.ynabtk-navlink-collapse').remove();

              this.setUpCollapseBtn();
              this.setUpCollapsedButtons();
            }
          }
        }
      }
    }, {
      key: 'setOriginalSizes',
      value: function setOriginalSizes() {
        this.originalSizes = {
          sidebarWidth: $('.sidebar').width(),
          contentLeft: $('.content').css('left'),
          headerLeft: $('.budget-header, .accounts-header').css('left'),
          contentWidth: $('.budget-content').outerWidth(),
          inspectorWidth: $('.budget-inspector').outerWidth()
        };
      }

      // Add buttons and handlers to screen

    }, {
      key: 'setupBtns',
      value: function setupBtns() {
        // Don't proceed if buttons already exist
        if ($('.ynabtk-navlink-collapse').is(':visible') || $('.navbar-expand').is(':visible')) {
          return;
        }

        this.setUpCollapseBtn();
        this.setUpCollapsedButtons();
      }
    }, {
      key: 'setUpCollapseBtn',
      value: function setUpCollapseBtn() {
        var _this = this;
        $('.nav-main').append(this.collapseBtn);
        $('body').on('click', '.ynabtk-navlink-collapse', _this, this.collapseMenu);
      }
    }, {
      key: 'setUpCollapsedButtons',
      value: function setUpCollapsedButtons() {
        var expandBtns = this.getUnCollapseBtnGroup();

        $('.sidebar').prepend(expandBtns);

        if ($('.sidebar-contents').is(':visible')) {
          $('.collapsed-buttons').hide();
        }
      }
    }, {
      key: 'clickFunction',
      value: function clickFunction() {
        this.originalButtons[this.className.replace(' active', '')].click();
        this.deactivateCollapsedActive();
        $(this).addClass('active');
      }
    }, {
      key: 'getUnCollapseBtnGroup',
      value: function getUnCollapseBtnGroup() {
        var navChildren = $('.nav-main').children();
        var navChildrenLength = navChildren.length;
        var collapsedBtnContainer = $('.collapsed-buttons');

        if (collapsedBtnContainer.length) {
          collapsedBtnContainer.children().remove();
          collapsedBtnContainer.hide();
        } else {
          collapsedBtnContainer = $('<div>', { class: 'collapsed-buttons', style: 'display: none' });
        }

        for (var i = 0; i < navChildrenLength; i++) {
          var child = navChildren[i];

          // If this is the collapse button, skip
          if (child.className.indexOf('ynabtk-navlink-collapse') > -1) {
            continue;
          }

          var span = $(child).find('span')[0];

          // Don't process if not actually a button
          if (!span) {
            continue;
          }

          var btnClasses = span.className;
          var button = $('<button>');
          button.addClass(btnClasses);
          button.addClass('button button-prefs');

          var listItem = $(child).find('li')[0] || child;
          var linkClasses = listItem.className.replace(' active', '');

          var link = $('<a>');
          link.attr('href', '#');
          link.addClass(linkClasses);
          link.html(button);
          link.click(this.clickFunction);

          this.originalButtons[linkClasses.replace(' active', '')] = $(child).find('a');

          // Set proper class so the active styling can be applied
          if (btnClasses.indexOf('mail-1') > -1) {
            button.addClass('collapsed-budget');
          } else if (btnClasses.indexOf('graph-1') > -1) {
            button.addClass('collapsed-reports');
          } else if (btnClasses.indexOf('government-1') > -1) {
            button.addClass('collapsed-account');
          } else {
            // Fallback if we don't know what the button is.
            button.addClass('collapsed');
          }

          collapsedBtnContainer.append(link);
        }

        // Add uncollapse button
        var collapseBtn = $('<button>', { class: 'button button-prefs flaticon stroke right-circle-4 navbar-expand' });

        collapsedBtnContainer.append(collapseBtn);

        $('body').on('click', '.navbar-expand', this, this.expandMenu);

        return collapsedBtnContainer;
      }

      // Handle clicking expand button. Puts things back to original sizes

    }, {
      key: 'expandMenu',
      value: function expandMenu(event) {
        var originalSizes = event.data.originalSizes;

        $('.collapsed-buttons').hide();
        $('.sidebar > .ember-view').fadeIn();
        $('.ynabtk-navlink-collapse').show();

        $('.sidebar').animate({ width: originalSizes.sidebarWidth });
        $('.content').animate({ left: originalSizes.contentLeft }, function () {
          $('.layout').removeClass('collapsed');
        });

        $('.budget-header').animate({ left: originalSizes.headerLeft });
        if ($('.budget-content').is(':visible')) {
          if (ynabToolKit.options.InspectorWidth !== '0') {
            $('.budget-inspector')[0].style.setProperty('--toolkit-inspector-minwidth', 'inherit');
          }
        }
      }

      // Handle clicking the collapse button

    }, {
      key: 'collapseMenu',
      value: function collapseMenu(event) {
        var _this = event.data;
        // resize-inspector feature could have changed these so fetch current sizes.
        _this.setOriginalSizes();
        _this.setActiveButton($('.nav-main li.active').attr('class'));
        $('.ynabtk-navlink-collapse').hide();
        $('.sidebar > .ember-view').hide();
        $('.collapsed-buttons').fadeIn();

        $('.sidebar').animate({ width: '40px' });
        $('.content').animate({ left: '40px' }, 400, 'swing', function () {
          // Need to remove width after animation completion
          $('.ynab-grid-header').removeAttr('style');

          // We don't use these in our CSS, it's mostly so other features can observe
          // for collapse/expand and update sizes / do whatever. E.g. reports needs
          // to resize its canvas when this happens.
          $('.ynabtk-navlink-collapse').removeClass('expanded').addClass('collapsed');
          $('.layout').addClass('collapsed');
        });

        $('.budget-header').animate({ left: '40px' });
        if ($('.budget-content').is(':visible')) {
          if (ynabToolKit.options.InspectorWidth !== '0') {
            $('.budget-inspector')[0].style.setProperty('--toolkit-inspector-minwidth', '276 px');
          }
        }
      }

      // Add the active style to correct button

    }, {
      key: 'setActiveButton',
      value: function setActiveButton(button) {
        if (typeof button !== 'undefined') {
          this.deactivateCollapsedActive();
          button = button.replace('active', '').replace('ember-view', '').trim();
          $('.collapsed-buttons a.' + button).addClass('active');
        } else {
          $('.collapsed-buttons a').removeClass('active');
        }
      }

      // Deactivate collapsed buttons

    }, {
      key: 'deactivateCollapsedActive',
      value: function deactivateCollapsedActive() {
        $('.collapsed-buttons a').removeClass('active');
      }
    }]);

    return CollapseSideMenu;
  }(_feature.Feature);

  /***/
},
/* 115 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(116);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 116 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".ynabtk-navlink-collapse {\n  cursor: pointer;\n}\n\n.layout.collapsed .content,\n.layout.collapsed .budget-header {\n\tleft: 40px;\n}\n\n.layout.collapsed .content .scroll-wrap {\n\twidth: inherit;\n\tmin-width: 838px;\n}\n\n.collapsed-buttons .active button {\n\tbackground-color: #194853;\n\tcolor: #fff;\n}\n\n.collapsed-buttons .active .collapsed-budget {\n\tcolor: #ceec00;\n}\n\n.collapsed-buttons .active .collapsed-reports {\n\tcolor: #fed168;\n}\n\n.collapsed-buttons .active .collapsed-account {\n\tcolor: #32dcff;\n}\n", ""]);

  // exports


  /***/
},
/* 117 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ColourBlindMode = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ColourBlindMode = exports.ColourBlindMode = function (_Feature) {
    _inherits(ColourBlindMode, _Feature);

    function ColourBlindMode() {
      _classCallCheck(this, ColourBlindMode);

      return _possibleConstructorReturn(this, (ColourBlindMode.__proto__ || Object.getPrototypeOf(ColourBlindMode)).apply(this, arguments));
    }

    _createClass(ColourBlindMode, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(118);
      }
    }]);

    return ColourBlindMode;
  }(_feature.Feature);

  /***/
},
/* 118 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(119);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 119 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "/* ======== General colours / shapes ======== */\n.inspector dt {\n\tcolor: black !important;\n}\n\n/* ======== Cautious colours / shapes ======== */\n.budget-table-row.is-sub-category > .budget-table-cell-available .cautious {\n    background-color: #19a3c5 !important;\n}\n\n.inspector-overview-available .currency.cautious {\n    background-color: #19a3c5 !important;;\n}\n\n.budget-table-row.is-sub-category > .budget-table-cell-available .cautious:hover {\n    background-color: #14839e !important;\n}\n\n/* ======== Goal-related colours / shapes ======== */\n.toolkit-row-goal.toolkit-row-availablepositive .budget-table-cell-available .cautious, \n.toolkit-row-goal.toolkit-row-availablezero .budget-table-cell-available .cautious {\n\tbackground: #1282a0 !important;\n}\n.toolkit-row-goal.toolkit-row-availablepositive .budget-table-cell-available .cautious:hover, \n.toolkit-row-goal.toolkit-row-availablezero .budget-table-cell-available .cautious:hover {\n\tbackground: #0e6c85 !important;\n}\n\n.toolkit-row-goal.toolkit-row-availablepositive dd .cautious, \n.toolkit-row-goal.toolkit-row-availablezero dd .cautious {\n\tbackground: #1282a0 !important;\n}\n.toolkit-row-goal.toolkit-row-availablepositive dd .cautious:hover, \n.toolkit-row-goal.toolkit-row-availablezero dd .cautious:hover {\n\tbackground: #0e6c85 !important;\n}\n\n/* ======== Negative colours / shapes ======== */\nul.is-sub-category > li.budget-table-cell-available > div.budget-table-cell-available-div > span.negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n    background-color: #d55e00 !important;\n}\n\n.inspector-overview-available .currency.negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n    background-color: #d55e00 !important;\n}\n\n.left-to-budget-is-negative .budget-header-totals-amount {\n    border-radius: 0em;\n    -webkit-border-radius: 0em;\n    background-color: #d55e00 !important;\n}\n\n.left-to-budget-is-negative .budget-header-totals-amount-arrow .arrow {\n    border-left-color: #d55e00 !important;\n}\n\n/* ======== Positive colours / shapes ======== */\nul.is-sub-category > li.budget-table-cell-available > div.budget-table-cell-available > span.positive {\n    background-color: #009e73 !important;\n    color: #fff !important;\n    font-weight: normal !important;\n}\n\n.inspector-overview-available .currency.positive {\n    background-color: #009e73 !important;;\n    color: #fff !important;\n    font-weight: normal !important;\n}\n", ""]);

  // exports


  /***/
},
/* 120 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.EditAccountButton = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var EditAccountButton = exports.EditAccountButton = function (_Feature) {
    _inherits(EditAccountButton, _Feature);

    function EditAccountButton() {
      _classCallCheck(this, EditAccountButton);

      return _possibleConstructorReturn(this, (EditAccountButton.__proto__ || Object.getPrototypeOf(EditAccountButton)).apply(this, arguments));
    }

    _createClass(EditAccountButton, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1' && !YNABFEATURES['edit-account-icon']) {
          return __webpack_require__(121);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(123);
        }
      }
    }]);

    return EditAccountButton;
  }(_feature.Feature);

  /***/
},
/* 121 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(122);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 122 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-account-row .nav-account-name i {\n  padding-top: 2px;\n  padding-right: 4px;\n  float:left;\n  transition: opacity .25s ease-in-out;\n}\n", ""]);

  // exports


  /***/
},
/* 123 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(124);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 124 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-account-row:hover .nav-account-name .edit-account-icon {\n\tdisplay: none;\n}\n\n.nav-account-row:hover .nav-account-notification .edit-account-icon {\n\tdisplay: none;\n}\n\n.nav-account-row .nav-account-name:hover button {\n\tmax-width: 100%;\n}\n", ""]);

  // exports


  /***/
},
/* 125 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.GoogleFontsSelector = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var GoogleFontsSelector = exports.GoogleFontsSelector = function (_Feature) {
    _inherits(GoogleFontsSelector, _Feature);

    function GoogleFontsSelector() {
      _classCallCheck(this, GoogleFontsSelector);

      return _possibleConstructorReturn(this, (GoogleFontsSelector.__proto__ || Object.getPrototypeOf(GoogleFontsSelector)).apply(this, arguments));
    }

    _createClass(GoogleFontsSelector, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1') {
          return __webpack_require__(126);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(128);
        } else if (this.settings.enabled === '3') {
          return __webpack_require__(130);
        } else if (this.settings.enabled === '4') {
          return __webpack_require__(132);
        }
      }
    }]);

    return GoogleFontsSelector;
  }(_feature.Feature);

  /***/
},
/* 126 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(127);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 127 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports
  exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,700);", ""]);
  exports.i(__webpack_require__(3), "");

  // module
  exports.push([module.i, ".ember-view {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.budget-header-calendar .budget-header-calendar-date-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.budget-inspector-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.budget-inspector-goals .link-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.inspector-category-edit {\n    font-family: 'Open Sans', sans-serif;\n    top: 3px;\n    font-size: 1em;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-popup .modal-actions .button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-generic .modal-actions .button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-generic .modal-header {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-popup .modal-content {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-account-filters .modal-header {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-account-filters .date-range-dates li.active button, .modal-account-filters .date-range-dates li:hover button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-popup ul.modal-list button {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.modal-account-approve-reject.modal-account-dropdown .modal, .modal-account-match-transaction.modal-account-dropdown .modal {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.edit-direct-connect-toggle {\n    font-family: 'Open Sans', sans-serif;\n}\n\n.account-modal .modal-content dt, .account-modal .modal-content dd {\n    font-family: 'Open Sans', sans-serif;\n}\n\n/* if reports stuff is enabled */\n.reports-inspector-detail {\n    font-family: 'Open Sans', sans-serif;\n}\n\n#reports-header {\n    font-family: 'Open Sans', sans-serif !important;\n}\n", ""]);

  // exports


  /***/
},
/* 128 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(129);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 129 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports
  exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Roboto:400,700,400italic);", ""]);
  exports.i(__webpack_require__(3), "");

  // module
  exports.push([module.i, ".ember-view {\n    font-family: 'Roboto', sans-serif;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.budget-header-calendar .budget-header-calendar-date-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.budget-inspector-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.budget-inspector-goals .link-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.inspector-category-edit {\n    font-family: 'Roboto', sans-serif;\n    top: 3px;\n    font-size: 1em;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-popup .modal-actions .button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-generic .modal-actions .button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-generic .modal-header {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-popup .modal-content {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-account-filters .modal-header {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-account-filters .date-range-dates li.active button, .modal-account-filters .date-range-dates li:hover button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-popup ul.modal-list button {\n    font-family: 'Roboto', sans-serif;\n}\n\n.modal-account-approve-reject.modal-account-dropdown .modal, .modal-account-match-transaction.modal-account-dropdown .modal {\n    font-family: 'Roboto', sans-serif;\n}\n\n.edit-direct-connect-toggle {\n    font-family: 'Roboto', sans-serif;\n}\n\n.account-modal .modal-content dt, .account-modal .modal-content dd {\n    font-family: 'Roboto', sans-serif;\n}\n\n/* if reports stuff is enabled */\n.reports-inspector-detail {\n    font-family: 'Roboto', sans-serif;\n}\n\n#reports-header {\n    font-family: 'Roboto', sans-serif !important;\n}\n", ""]);

  // exports


  /***/
},
/* 130 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(131);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 131 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports
  exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Roboto Condensed+Condensed:400,700,400italic);", ""]);
  exports.i(__webpack_require__(3), "");

  // module
  exports.push([module.i, ".ember-view {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.budget-header-calendar .budget-header-calendar-date-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.budget-inspector-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.budget-inspector-goals .link-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.inspector-category-edit {\n    font-family: 'Roboto Condensed', sans-serif;\n    top: 3px;\n    font-size: 1em;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-popup .modal-actions .button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-generic .modal-actions .button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-generic .modal-header {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-popup .modal-content {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-account-filters .modal-header {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-account-filters .date-range-dates li.active button, .modal-account-filters .date-range-dates li:hover button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-popup ul.modal-list button {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.modal-account-approve-reject.modal-account-dropdown .modal, .modal-account-match-transaction.modal-account-dropdown .modal {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.edit-direct-connect-toggle {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n.account-modal .modal-content dt, .account-modal .modal-content dd {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n/* if reports stuff is enabled */\n.reports-inspector-detail {\n    font-family: 'Roboto Condensed', sans-serif;\n}\n\n#reports-header {\n    font-family: 'Roboto Condensed', sans-serif !important;\n}\n", ""]);

  // exports


  /***/
},
/* 132 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(133);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 133 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports
  exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Droid+Sans:400,700);", ""]);
  exports.i(__webpack_require__(3), "");

  // module
  exports.push([module.i, ".ember-view {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.budget-header-calendar .budget-header-calendar-date-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.budget-inspector-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.budget-inspector-goals .link-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.inspector-category-edit {\n    font-family: 'Droid Sans', sans-serif;\n    top: 3px;\n    font-size: 1em;\n}\n\n.nav-account-block .nav-account-name-button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.budget-content ul, .budget-table-row.is-dragging {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-popup .modal-actions .button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-generic .modal-actions .button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-generic .modal-header {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-popup .modal-content {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-account-filters .modal-header {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-account-filters .date-range-dates li.active button, .modal-account-filters .date-range-dates li:hover button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-popup ul.modal-list button {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.modal-account-approve-reject.modal-account-dropdown .modal, .modal-account-match-transaction.modal-account-dropdown .modal {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.edit-direct-connect-toggle {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n.account-modal .modal-content dt, .account-modal .modal-content dd {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n/* if reports stuff is enabled */\n.reports-inspector-detail {\n    font-family: 'Droid Sans', sans-serif;\n}\n\n#reports-header {\n    font-family: 'Droid Sans', sans-serif !important;\n}\n", ""]);

  // exports


  /***/
},
/* 134 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.HideAccountBalancesType = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var HideAccountBalancesType = exports.HideAccountBalancesType = function (_Feature) {
    _inherits(HideAccountBalancesType, _Feature);

    function HideAccountBalancesType() {
      _classCallCheck(this, HideAccountBalancesType);

      return _possibleConstructorReturn(this, (HideAccountBalancesType.__proto__ || Object.getPrototypeOf(HideAccountBalancesType)).apply(this, arguments));
    }

    _createClass(HideAccountBalancesType, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1') {
          return __webpack_require__(4) + __webpack_require__(5);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(5);
        } else if (this.settings.enabled === '3') {
          return __webpack_require__(4);
        }
      }
    }]);

    return HideAccountBalancesType;
  }(_feature.Feature);

  /***/
},
/* 135 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-account-row .nav-account-value {\n    visibility: hidden;\n    width: 0px;\n}\n\n.nav-account-row .nav-account-spacer {\n    width: 0px;\n}\n\n.nav-account-row .nav-account-name {\n    overflow: inherit;\n    width: 210px\n}", ""]);

  // exports


  /***/
},
/* 136 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-account-block .nav-account-value {\n    visibility: hidden;\n    width: 0px;\n}", ""]);

  // exports


  /***/
},
/* 137 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.HideAgeOfMoney = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var HideAgeOfMoney = exports.HideAgeOfMoney = function (_Feature) {
    _inherits(HideAgeOfMoney, _Feature);

    function HideAgeOfMoney() {
      _classCallCheck(this, HideAgeOfMoney);

      return _possibleConstructorReturn(this, (HideAgeOfMoney.__proto__ || Object.getPrototypeOf(HideAgeOfMoney)).apply(this, arguments));
    }

    _createClass(HideAgeOfMoney, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(138);
      }
    }]);

    return HideAgeOfMoney;
  }(_feature.Feature);

  /***/
},
/* 138 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(139);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 139 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".budget-header-days {\n\tdisplay: none;\n\tborder-left: none;\n}\n", ""]);

  // exports


  /***/
},
/* 140 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.HideHelp = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var HideHelp = exports.HideHelp = function (_Feature) {
    _inherits(HideHelp, _Feature);

    function HideHelp() {
      _classCallCheck(this, HideHelp);

      return _possibleConstructorReturn(this, (HideHelp.__proto__ || Object.getPrototypeOf(HideHelp)).apply(this, arguments));
    }

    _createClass(HideHelp, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(141);
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return true;
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (changedNodes.has('ynab-u modal-popup modal-user-prefs ember-view modal-overlay active')) {
          this.invoke();
        }
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        var hide = toolkitHelper.getToolkitStorageKey('hide-help');

        if (hide === null) {
          toolkitHelper.setToolkitStorageKey('hide-help', 'true');
          hide = 'true';
        }

        if (hide === 'true') {
          $('body').addClass('toolkit-hide-help');
        }

        this.updatePopupButton();
      }
    }, {
      key: 'updatePopupButton',
      value: function updatePopupButton() {
        var $modal = $('.modal-user-prefs .modal');
        var $modalList = $('.modal-user-prefs .modal-list');

        if ($('.ynab-toolkit-hide-help', $modalList).length) return;

        var $label = 'Show';
        if ($('#hs-beacon').is(':visible')) {
          $label = 'Hide';
        }

        $('<li class="ynab-toolkit-hide-help">\n      <button>\n        <i class="flaticon stroke help-2"></i>\n        ' + $label + ' Help Button\n      </button>\n     </li>\n    ').click(function () {
          var hide = !toolkitHelper.getToolkitStorageKey('hide-help', 'boolean');
          toolkitHelper.setToolkitStorageKey('hide-help', hide);
          $('body').toggleClass('toolkit-hide-help');
          var accountController = ynabToolKit.shared.containerLookup('controller:accounts');
          accountController.send('closeModal');
        }).appendTo($modalList);

        $modal.css({ height: '+=12px' });
      }
    }]);

    return HideHelp;
  }(_feature.Feature);

  /***/
},
/* 141 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(142);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 142 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".toolkit-hide-help #hs-beacon {\n\tdisplay: none;\n}", ""]);

  // exports


  /***/
},
/* 143 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.HideReferralBanner = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var HideReferralBanner = exports.HideReferralBanner = function (_Feature) {
    _inherits(HideReferralBanner, _Feature);

    function HideReferralBanner() {
      _classCallCheck(this, HideReferralBanner);

      return _possibleConstructorReturn(this, (HideReferralBanner.__proto__ || Object.getPrototypeOf(HideReferralBanner)).apply(this, arguments));
    }

    _createClass(HideReferralBanner, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(144);
      }
    }]);

    return HideReferralBanner;
  }(_feature.Feature);

  /***/
},
/* 144 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(145);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 145 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "div.referral-program {\n    display: none;\n}\n", ""]);

  // exports


  /***/
},
/* 146 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ImportNotification = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ImportNotification = exports.ImportNotification = function (_Feature) {
    _inherits(ImportNotification, _Feature);

    _createClass(ImportNotification, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(147);
      }
    }]);

    function ImportNotification() {
      _classCallCheck(this, ImportNotification);

      var _this = _possibleConstructorReturn(this, (ImportNotification.__proto__ || Object.getPrototypeOf(ImportNotification)).call(this));

      _this.isActive = false;
      _this.importClass = 'import-notification';
      _this.invoke = _this.invoke.bind(_this);
      return _this;
    }

    _createClass(ImportNotification, [{
      key: 'willInvoke',
      value: function willInvoke() {
        if (this.settings.enabled !== '0') {
          if (this.settings.enabled === '2') {
            this.importClass += '-red';
          }

          // Hook transaction imports so that we can run our stuff when things change. The idea is for our code to
          // run when new imports show up while the user isn't doin ganythiing in the app. The down side is the
          // handler being called when the user does something like "approve a transaction". That's why this feature
          // has a blocking mechanism (the isActive flag).
          ynab.YNABSharedLib.defaultInstance.entityManager._transactionEntityPropertyChanged.addHandler(this.invoke);
        }
      }
    }, {
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return this.settings.enabled !== '0';
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        if (!this.isActive) {
          this.checkImportTransactions();
        }
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (!this.shouldInvoke()) return;
        // To minimize checking for imported transactions, only do it if the changed nodes includes ynab-grid-body
        // if we're not already actively check.
        if (changedNodes.has('ynab-grid-body') && !this.isActive) {
          this.invoke();
        }
      }
    }, {
      key: 'checkImportTransactions',
      value: function checkImportTransactions() {
        var _this2 = this;

        this.isActive = true;

        $('.' + this.importClass).remove();
        $('.nav-account-row').each(function (index, row) {
          var account = ynabToolKit.shared.getEmberView($(row).attr('id')).get('data');

          // Check for both functions should be temporary until all users have been switched to new bank data
          // provider but of course we have no good way of knowing when that has occurred.
          if (typeof account.getDirectConnectEnabled === 'function' && account.getDirectConnectEnabled() || typeof account.getIsDirectImportActive === 'function' && account.getIsDirectImportActive()) {
            var t = new ynab.managers.DirectImportManager(ynab.YNABSharedLib.defaultInstance.entityManager, account);
            var transactions = t.getImportTransactionsForAccount(account);

            if (transactions.length >= 1) {
              $(row).find('.nav-account-notification').append('<a class="notification ' + _this2.importClass + '">' + transactions.length + '</a>');
            }
          }
        });
        this.isActive = false;
      }
    }]);

    return ImportNotification;
  }(_feature.Feature);

  /***/
},
/* 147 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(148);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 148 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".import-notification {\n  background-color: #227e99;\n}\n\n.import-notification-red {\n  background-color: #FF0000;\n}\n", ""]);

  // exports


  /***/
},
/* 149 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.NavDisplayDensity = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var NavDisplayDensity = exports.NavDisplayDensity = function (_Feature) {
    _inherits(NavDisplayDensity, _Feature);

    function NavDisplayDensity() {
      _classCallCheck(this, NavDisplayDensity);

      return _possibleConstructorReturn(this, (NavDisplayDensity.__proto__ || Object.getPrototypeOf(NavDisplayDensity)).apply(this, arguments));
    }

    _createClass(NavDisplayDensity, [{
      key: 'injectCSS',
      value: function injectCSS() {
        if (this.settings.enabled === '1') {
          return __webpack_require__(150);
        } else if (this.settings.enabled === '2') {
          return __webpack_require__(152);
        }
      }
    }]);

    return NavDisplayDensity;
  }(_feature.Feature);

  /***/
},
/* 150 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(151);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 151 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-main {\n     padding-bottom: .95em !important;\n}\n.nav-main a {\n     padding: 0 !important;\n     font-size: 1em !important;\n}", ""]);

  // exports


  /***/
},
/* 152 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(153);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 153 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".nav-main {\n     padding-bottom: .5em !important;\n}\n.nav-main a {\n     padding: 0 !important;\n     font-size: .85em !important;\n}", ""]);

  // exports


  /***/
},
/* 154 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.PrintingImprovements = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var PrintingImprovements = exports.PrintingImprovements = function (_Feature) {
    _inherits(PrintingImprovements, _Feature);

    function PrintingImprovements() {
      _classCallCheck(this, PrintingImprovements);

      return _possibleConstructorReturn(this, (PrintingImprovements.__proto__ || Object.getPrototypeOf(PrintingImprovements)).apply(this, arguments));
    }

    _createClass(PrintingImprovements, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(155);
      }
    }]);

    return PrintingImprovements;
  }(_feature.Feature);

  /***/
},
/* 155 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(156);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 156 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "/* ======== Budget Printing Improvements ======== */\n@media print {\n\n\t/* hide unneeded areas */\n\tbody nav.sidebar,\n\tbody aside.budget-inspector,\n\tbody .inspector-resize-handle,\n\tbody .budget-table-row .budget-table-cell-budgeted .goal-indicator {\n\t\tdisplay: none;\n\t}\n\n\n\t/* hide header, yet ensure that month is still visible */\n\tbody .budget-header-item,\n\tbody .budget-header-days.days-of-buffering,\n\tbody .budget-header-item button,\n\tbody .budget-header-calendar .budget-header-calendar-note,\n\tbody .budget-header-calendar .budget-header-calendar-date-button i,\n\tbody .budget-toolbar {\n\t\tdisplay: none;\n\t}\n\tbody .budget-header-days.days-of-buffering {\n\t\tdisplay: none !important;\n\t}\n\tbody .budget-header,\n\tbody .accounts-header {\n\t\tleft: 0;\n\t\tposition: relative;\n\t}\n\tbody .budget-header .budget-header-item,\n\tbody .toolkit-highlight-current-month {\n\t\tbackground: transparent !important;\n\t\tpadding-left: .8em;\n\t}\n\tbody .budget-header-calendar,\n\tbody .budget-header-calendar .budget-header-calendar-date-button {\n\t\tdisplay: block;\n\t\tcolor: #000;\n\t\ttext-align: left;\n\t}\n\n\t/* primarily layout adjustments */\n\t@page { margin: 1cm; }\n\n\t* {\n\t\tflex: none !important;\n\t}\n\tbody .ynab-u {\n\t\tdisplay: block;\n\t}\n\tbody .resize-inspector {\n\t\tdisplay: block !important;\n\t}\n\thtml, body {\n\t\theight: auto;\n\t\toverflow-y: visible !important;\n\t\toverflow-x: hidden !important;\n\t\twidth: 100%;\n\t\tmin-height: 100%;\n\t}\n\tbody div.content,\n\tbody section.budget-content {\n\t\tposition: relative !important;\n\t\twidth: 100%;\n\t\tmin-height: 100%;\n\t\tmin-width: 0;\n\t\ttop: auto;\n\t\tright: auto;\n\t\tbottom: auto;\n\t\tleft: auto;\n\t\toverflow-x: hidden !important;\n\t\tfont-size: 1em;\n\t\tpadding-top: 0;\n\t\tflex: none;\n\t}\n\tbody ul.budget-table-header {\n\t\tposition: relative !important;\n\t\tborder-bottom: 0;\n\t\tmin-width: 0;\n\t\tfont-weight: bold;\n\t}\n\tbody div.budget-table {\n\t\tposition: relative !important;\n\t\ttop: 0;\n\t\tmin-width: 0;\n\t\theight: auto;\n\t\tmin-height: 100%;\n\t\tpadding-bottom: 50px;\n\t}\n\tbody .budget-table-row {\n\t\tpage-break-inside: avoid;\n\t}\n\n\tbody .budget-table-header .budget-table-cell-checkbox,\n\tbody .budget-table-row .budget-table-cell-checkbox,\n\tbody .budget-table-header .budget-table-cell-status,\n\tbody .budget-table-row .budget-table-cell-status {\n\t\tdisplay: none;\n\t}\n\n\tbody .budget-table-header .budget-table-cell-name,\n\tbody .budget-table-row .budget-table-cell-name\n\t{\n\t\twidth: 42% !important;\n\t}\n\t.budget-table-header .budget-table-cell-budgeted,\n\t.budget-table-row .budget-table-cell-budgeted,\n\t.budget-table-header .budget-table-cell-activity,\n\t.budget-table-row .budget-table-cell-activity,\n\t.budget-table-header .budget-table-cell-available,\n\t.budget-table-row .budget-table-cell-available,\n\t.budget-table-header .budget-table-cell-pacing {\n\t\twidth: 12% !important;\n\t\tfont-size: 8pt !important;\n\t}\n\n\tbody .budget-table-row.is-master-category {\n\t\tborder-top: 2px solid #ccc;\n\t\tbackground: transparent;\n\t\tmargin-top: 20px;\n\t\theight: 2.1em;\n\t}\n\tbody .budget-table-row.is-master-category .budget-table-cell-name .budget-table-cell-name-row-label-item {\n\t    padding-top: .3em;\n\t}\n\tbody .budget-table-row.is-master-category:first-child {\n\t\tmargin-top: 0;\n\t}\n\n\tbody .budget-table-row.is-sub-category {\n\t\theight: 1.8em;\n\t}\n\tbody .budget-table-header .budget-table-cell-budgeted,\n\tbody .budget-table-header .budget-table-cell-activity,\n\tbody .budget-table-header .budget-table-cell-available,\n\tbody .budget-table-header .budget-table-cell-pacing {\n\t\tpadding-right: 0 !important;\n\t}\n\n\n\t/* primarily font styling */\n\tbody .budget-table-row.is-master-category .budget-table-cell-name {\n\t\tfont-weight: bold;\n\t}\n\t.budget-table-cell-name-static-width {\n\t\twidth: 18px;\n\t}\n\tbody .budget-table-row.is-master-category .budget-table-cell-name button {\n\t\tfont-weight: bold;\n\t\tposition: relative;\n\t\ttop: 2px !important;\n\t}\n\tbody .button, body .button-red, body .button-disabled {\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-master-category .positive,\n\tbody .budget-table-row.is-master-category .negative,\n\tbody .budget-table-row.is-master-category .cautious,\n\tbody .budget-table-row.is-master-category .zero {\n\t\tfont-weight: bold;\n\t\tcolor: #000;\n\t\tpadding-right: 2px;\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .positive,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .negative,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .cautious,\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\t\tbackground-color: transparent;\n\t\tpadding: 0 2px 0 0 !important;\n\t\tfont-size: 9pt !important;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .positive {\n\t\tcolor: #16a336;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .cautious {\n\t\tcolor: #e59100;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .negative {\n\t\tcolor: #d33c2d;\n\t}\n\tbody .budget-table-row.is-sub-category > .budget-table-cell-available .zero {\n\t\tcolor: #000000;\n\t}\n\n}\n\n\n/* ======== Account Printing Improvements ======== */\n@media print {\n\n\t/* header layout adjustments */\n\t.accounts-toolbar,\n\t.accounts-header .accounts-header-total-inner .arrow,\n\t.accounts-header-reconcile {\n\t\tdisplay: none;\n\t}\n\t.accounts-header {\n\t\theight: auto;\n\t\tbackground: transparent;\n\t}\n\t.accounts-header .accounts-header-total-inner {\n\t\tpadding-left: 0;\n\t\tpadding-right: 60px;\n\t\tbackground: transparent;\n\t}\n\t.accounts-header .accounts-header-total-inner .accounts-header-total-inner-label,\n\t.accounts-header .accounts-header-balances-label {\n\t\tcolor: #000;\n\t\tline-height: 1.5em;\n\t    font-weight: 400;\n\t}\n\n\t/* transactions adjustments */\n\t.ynab-grid {\n\t\tposition: relative !important;\n\t\theight: auto !important;\n\t\tfont-size: 11pt !important;\n\t}\n\t.ynab-grid-container {\n\t\theight: auto !important;\n\t}\n\t.ynab-grid-header,\n\t.ynab-grid-cell-checkbox {\n\t\tdisplay: none;\n\t}\n\n\t.ynab-grid-body-row,\n\t.ynab-grid-body-row-top,\n\t.ynab-grid-body-row-bottom {\n\t\theight: 26px !important;\n\t\tpage-break-inside: avoid;\n\t}\n\t.ynab-grid-cell {\n\t    padding: .2em 0;\n\t}\n\t.ynab-grid-body-row.is-scheduled {\n\t\tdisplay: none;\n\t}\n\n}", ""]);

  // exports


  /***/
},
/* 157 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.PrivacyMode = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var PrivacyMode = exports.PrivacyMode = function (_Feature) {
    _inherits(PrivacyMode, _Feature);

    function PrivacyMode() {
      _classCallCheck(this, PrivacyMode);

      return _possibleConstructorReturn(this, (PrivacyMode.__proto__ || Object.getPrototypeOf(PrivacyMode)).apply(this, arguments));
    }

    _createClass(PrivacyMode, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        return true;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        var toggle = ynabToolKit.shared.getToolkitStorageKey('privacy-mode', 'boolean');
        if (typeof toggle === 'undefined') {
          ynabToolKit.shared.setToolkitStorageKey('privacy-mode', false);
        }

        if (ynabToolKit.options.PrivacyMode === '2') {
          if (!$('#toolkit-togglePrivacy').length) {
            $('nav.sidebar.logged-in .sidebar-contents').after('<button id="toolkit-togglePrivacy"><i class="ember-view flaticon stroke lock-1"></i></button>');

            var parent = this;
            $('body').on('click', 'button#toolkit-togglePrivacy', function () {
              parent.togglePrivacyMode();
            });
          }
        } else if (ynabToolKit.options.PrivacyMode === '1') {
          ynabToolKit.shared.setToolkitStorageKey('privacy-mode', true);
        }

        this.updatePrivacyMode();
      }
    }, {
      key: 'injectCSS',
      value: function injectCSS() {
        var css = __webpack_require__(158);

        if (this.settings.enabled === '2') {
          css += __webpack_require__(160);
        }

        return css;
      }
    }, {
      key: 'togglePrivacyMode',
      value: function togglePrivacyMode() {
        $('button#toolkit-togglePrivacy').toggleClass('active');

        var toggle = ynabToolKit.shared.getToolkitStorageKey('privacy-mode', 'boolean');
        ynabToolKit.shared.setToolkitStorageKey('privacy-mode', !toggle);
        this.updatePrivacyMode();
      }
    }, {
      key: 'updatePrivacyMode',
      value: function updatePrivacyMode() {
        var toggle = ynabToolKit.shared.getToolkitStorageKey('privacy-mode', 'boolean');

        if (toggle) {
          $('body').addClass('toolkit-privacyMode');
          $('#toolkit-togglePrivacy i').removeClass('unlock-1').addClass('lock-1');
        } else {
          $('body').removeClass('toolkit-privacyMode');
          $('#toolkit-togglePrivacy i').removeClass('lock-1').addClass('unlock-1');
        }
      }
    }]);

    return PrivacyMode;
  }(_feature.Feature);

  /***/
},
/* 158 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(159);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 159 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".toolkit-privacyMode .currency,\n.toolkit-privacyMode .button-prefs-user,\n\n.toolkit-privacyMode .reports-inspector .currency,\n\n.toolkit-privacyMode .ynabtk-category-entry-amount,\n.toolkit-privacyMode .ynabtk-payee-entry-amount,\n.toolkit-privacyMode .ynabtk-tbody .col-data,\n.toolkit-privacyMode .net-income .ynabtk-header-row .col-data,\n.toolkit-privacyMode .ynabtk-footer-row .col-data {\n  filter: url('data:image/svg+xml;charset=utf-8,<svg xmlns=\"http://www.w3.org/2000/svg\"><filter id=\"filter\"><feGaussianBlur stdDeviation=\"3\" /></filter></svg>#filter');\n  -webkit-filter: blur(10px);\n  filter: blur(10px);\n}\n\n.toolkit-privacyMode .button-prefs-user:hover,\n.toolkit-privacyMode *:hover > .currency,\n.toolkit-privacyMode *:hover > * > .currency,\n.toolkit-privacyMode .currency:hover,\n\n.toolkit-privacyMode .c3-tooltip-container .currency,\n\n.toolkit-privacyMode .ynabtk-category-entry:hover .ynabtk-category-entry-amount,\n.toolkit-privacyMode .ynabtk-payee-entry:hover .ynabtk-payee-entry-amount,\n.toolkit-privacyMode .ynabtk-tbody .col-data:hover,\n.toolkit-privacyMode .net-income .ynabtk-header-row .col-data:hover,\n.toolkit-privacyMode .ynabtk-footer-row .col-data:hover {\n  -webkit-filter: initial;\n  filter: initial;\n}\n\n/* YNAB Reports: Spending */\n.toolkit-privacyMode .c3-chart-arcs .c3-chart-arcs-title tspan:last-child,\n.toolkit-privacyMode .c3-axis-y text tspan {\n    fill: #ffffff !important;\n    color: #ffffff !important;\n}\n.toolkit-privacyMode .c3-chart-arcs .c3-chart-arcs-title:hover tspan:last-child,\n.toolkit-privacyMode .c3-axis-y:hover text tspan {\n    color: #0d233a !important;\n    fill: #0d233a !important;\n}\n\n/* Toolkit Reports: Net Worth */\n.toolkit-privacyMode .highcharts-yaxis-labels text tspan {\n    fill: #ffffff !important;\n    color: #ffffff !important;\n}\n.toolkit-privacyMode .highcharts-yaxis-labels:hover text tspan {\n    fill: #606060 !important;\n    color: #606060 !important;\n}\n\n/* Toolkit Reports: Spending by category, payee */\n.toolkit-privacyMode .highcharts-title tspan:last-child,\n.toolkit-privacyMode .highcharts-data-labels text tspan:last-child {\n    fill: #ffffff !important;\n    color: #ffffff !important;\n}\n\n.toolkit-privacyMode .highcharts-title:hover tspan:last-child,\n.toolkit-privacyMode .highcharts-data-labels text:hover tspan:last-child {\n    color: #0d233a !important;\n    fill: #0d233a !important;\n}", ""]);

  // exports


  /***/
},
/* 160 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(161);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 161 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, ".collapsed-buttons {\n\tmargin-top: 42px;\n}\n\n#toolkit-togglePrivacy {\n    color: #bee6ef;\n    top: 2px;\n    right: 2px;\n    position: absolute;\n    padding: 10px;\n}\n\n#toolkit-togglePrivacy.active {\n\tcolor: #fff;\n}", ""]);

  // exports


  /***/
},
/* 162 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ShowIntercom = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  var _toolkit = __webpack_require__(2);

  var toolkitHelper = _interopRequireWildcard(_toolkit);

  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
        }
      }newObj.default = obj;return newObj;
    }
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var ShowIntercom = exports.ShowIntercom = function (_Feature) {
    _inherits(ShowIntercom, _Feature);

    function ShowIntercom() {
      _classCallCheck(this, ShowIntercom);

      return _possibleConstructorReturn(this, (ShowIntercom.__proto__ || Object.getPrototypeOf(ShowIntercom)).apply(this, arguments));
    }

    _createClass(ShowIntercom, [{
      key: 'shouldInvoke',
      value: function shouldInvoke() {
        // should only invoke when the user settings modal is open which isn't
        // going to be the case when this lifecycle method is called.
        return false;
      }
    }, {
      key: 'invoke',
      value: function invoke() {
        var $modal = $('.modal-user-prefs .modal');
        var $modalList = $('.modal-user-prefs .modal-list');

        if ($('.ynab-toolkit-show-intercom', $modalList).length) return;

        $('<li class="ynab-toolkit-show-intercom">\n        <button>\n          <i class="flaticon stroke warning-2"></i>\n          Show Intercom\n        </button>\n      </li>\n    ').click(function () {
          var accountController = toolkitHelper.controllerLookup('accounts');
          window.Intercom('show'); // eslint-disable-line new-cap
          accountController.send('closeModal');
        }).appendTo($modalList);

        $modal.css({ height: '+=12px' });
      }
    }, {
      key: 'observe',
      value: function observe(changedNodes) {
        if (changedNodes.has('ynab-u modal-popup modal-user-prefs ember-view modal-overlay active')) {
          this.invoke();
        }
      }
    }]);

    return ShowIntercom;
  }(_feature.Feature);

  /***/
},
/* 163 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SquareNegativeMode = undefined;

  var _createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
      }
    }return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
    };
  }();

  var _feature = __webpack_require__(1);

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }return call && ((typeof call === 'undefined' ? 'undefined' : _typeof(call)) === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === 'undefined' ? 'undefined' : _typeof(superClass)));
    }subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  var SquareNegativeMode = exports.SquareNegativeMode = function (_Feature) {
    _inherits(SquareNegativeMode, _Feature);

    function SquareNegativeMode() {
      _classCallCheck(this, SquareNegativeMode);

      return _possibleConstructorReturn(this, (SquareNegativeMode.__proto__ || Object.getPrototypeOf(SquareNegativeMode)).apply(this, arguments));
    }

    _createClass(SquareNegativeMode, [{
      key: 'injectCSS',
      value: function injectCSS() {
        return __webpack_require__(164);
      }
    }]);

    return SquareNegativeMode;
  }(_feature.Feature);

  /***/
},
/* 164 */
/***/function (module, exports, __webpack_require__) {

  var result = __webpack_require__(165);

  if (typeof result === "string") {
    module.exports = result;
  } else {
    module.exports = result.toString();
  }

  /***/
},
/* 165 */
/***/function (module, exports, __webpack_require__) {

  exports = module.exports = __webpack_require__(0)(undefined);
  // imports


  // module
  exports.push([module.i, "/* Sidebar Numbers */\n.nav-accounts .negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Accounts Header */\n.accounts-header .accounts-header-total-inner.negative-working-balance {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Bugdet Header */\n.left-to-budget-is-negative .budget-header-totals-amount {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Budget Numbers, pacing */\nli.budget-table-cell-available > div.budget-table-cell-available-div > span.negative,\nli.toolkit-row-availablenegative > budget-table-cell-available-div > span.cautious,\nli.budget-table-cell-pacing span.negative {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n/* Budget Inspector */\n.inspector-overview-available .currency.negative,\n.toolkit-row-availablenegative .currency.cautious {\n    border-radius: 0em !important;\n    -webkit-border-radius: 0em !important;\n}\n\n", ""]);

  // exports


  /***/
}]
/******/);